const db = wx.cloud.database()
Page({

    /**
     * 页面的初始数据
     */
    data: {
        isLogin: false,
        uname: 'xxxxx',
        userId: 'xxxx',
        avator:'https://img0.baidu.com/it/u=1240274933,2284862568&fm=253&fmt=auto&app=138&f=PNG?w=180&h=180',
        postNumber:0
    },
    onLogin() {
        wx.navigateTo({
            url: '/pages/login/login',
        })
    },
    //   跳转到个人信息页面
    toPerson() {
        wx.navigateTo({
          url: '/pages/person/person',
        })
        
    },
    // 修改登录状态的逻辑
    taggleLogin(){
        const id = wx.getStorageSync("id")
        const userId = wx.getStorageSync('userId')
        const avator = wx.getStorageSync('avator')
        const uname =  wx.getStorageSync('uname')
        // console.log("身份认证", id)
        if (id) {
            this.setData({
                isLogin: true,
                userId,
                avator,
                uname
            })
        }else{
            this.setData({
                isLogin: false,
                userId:'xxxx',
                avator:"https://img0.baidu.com/it/u=1240274933,2284862568&fm=253&fmt=auto&app=138&f=PNG?w=180&h=180",
                uname:'xxxxx'
            })
        }
    },
    // 跳转到发布的商品页面
    toTrand(){
        wx.navigateTo({
          url: '/pages/trand/trand',
        })
    },
    // 获取发布的商品个数
    getCount(){ 
        const id = wx.getStorageSync('id')
        // console.log(openid)
        db.collection("goods").where({
            id:id
        }).get().then(res=>{
            this.setData({
                postNumber:res.data.length
            })
        })
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
       this.taggleLogin()
       this.getCount()
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {
        this.taggleLogin()
        this.getCount()
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {
        this.onLoad()
         wx.stopPullDownRefresh();
    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})