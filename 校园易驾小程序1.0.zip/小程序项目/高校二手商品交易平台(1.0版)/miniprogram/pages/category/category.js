const db = wx.cloud.database()
const hitFn = require("../../utils/index")
let categoryName = {
    1: "雅迪",
    2: "绿源",
    3: "爱玛",
    4: "九号",
    5: "小牛",
    6: "台铃",
    7: "特惠专区",
    8: "检测专区"
}
Page({

    /**
     * 页面的初始数据
     */
    data: {
        // 默认选中第一个
        curNav: 1,
        navList: [{
            id: 1,
            name: '雅迪'
        },
        {
            id: 2,
            name: '绿源'
        },
        {
            id: 3,
            name: '爱玛'
        },
        {
            id: 4,
            name: '九号'
        },
        {
            id: 5,
            name: '小牛'
        },
        {
            id: 6,
            name: '台铃'
        },
        {
            id: 7,
            name: '特惠专区'
        },
        {
            id: 8,
            name: '检测专区'
        }
        ],
        rightList: [],
        islogin: Boolean,
        showToast: Boolean
    },
    /* 把点击到的某一项 设为当前curNav   */
    switchRightTab: function (e) {
        let id = e.target.dataset.id;
        if (!id) {
            wx.setStorageSync('paramKey', "1");
        } else {
            wx.setStorageSync('paramKey', id);
        }
        this.setData({
            curNav: id
        })
        this.getData()
    },
    // 获取数据
    getData() {

        // console.log(gategoeyName[this.data.curNav])
        db.collection("goods").where({
            category: categoryName[this.data.curNav]
        }).get().then(res => {
            this.setData({
                rightList: res.data,
            })
            if (res.data.length === 0) {
                this.setData({
                    showToast: true
                })
            } else {
                this.setData({
                    showToast: false
                })
            }
        })
    },
    // 传参跳转到商品详情页面
    toDetail(event) {
        const goods_id = event.currentTarget.dataset.param;
        hitFn.updateHit(this.data.islogin,goods_id)
    },



    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
        // 默认curNav等于1时获取数据
        this.getData()
        const paramValue = wx.getStorageSync('paramKey');
        // 进行参数处理
        this.setData({
            curNav: paramValue,
            islogin: wx.getStorageSync('islogin')
        })
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {
        const paramValue = wx.getStorageSync('paramKey');
        this.setData({
            curNav: paramValue,
            islogin: wx.getStorageSync('islogin')
        })
        this.getData() 
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {
        this.onLoad();
    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})