// 连接云数据库
const db = wx.cloud.database()
const _ = db.command
const hitFn = require("../../utils/index")
Page({

    /**
     * 页面的初始数据
     */
    data: {
        classtrends: true,
        classlife: false,
        newGoodsList: [],
        islogin: Boolean
    },
    totrends() {
        this.setData({
            classtrends: true,
            classlife: false
        })
    },
    tolife() {
        this.setData({
            classtrends: false,
            classlife: true
        })
    },

    // 获取数据
    getData() {
        db.collection("goods").get().then(res => {
            // console.log(res)
            this.setData({
                newGoodsList: res.data
            })
        })
    },

    // 浏览量监听逻辑
    countView(e) {
        const param = e.currentTarget.dataset.param
        hitFn.updateHit(this.data.islogin,param)
    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
        this.getData()
        db.collection("goods").watch({
            onChange: res => {
                this.setData({
                    newGoodsList: res.docs,
                })
            },
            onError: err => {
                // console.log(err)
            }
        })
        this.setData({
            islogin: wx.getStorageSync('islogin')
        })
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {
        this.setData({
            islogin: wx.getStorageSync('islogin')
        })
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {
        this.getData()
        // 数据加载完成后，停止下拉刷新动画
        wx.stopPullDownRefresh();
        wx.showToast({
            title: '刷新成功!',
            icon: "success"
        })
    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})