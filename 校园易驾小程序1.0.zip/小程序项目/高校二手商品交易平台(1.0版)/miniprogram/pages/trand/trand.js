// 连接云数据库
const db = wx.cloud.database()
const _ = db.command
Page({

    /**
     * 页面的初始数据
     */
    data: {
        classup: true,
        classdown: false,
        newGoodsList: [],
        downGoodsList: [],
        goods_id: "",
        isShow: Boolean,
        contents: ""
    },
    toup() {
        this.setData({
            classup: true,
            classdown: false
        })
        this.getData()


    },
    todown() {
        this.setData({
            classup: false,
            classdown: true
        })
        this.getDownGoods()
    },

    // 获取在卖商品数据
    getData() {
        const id = wx.getStorageSync('id')
        db.collection("goods").where({
            id: id
        }).get().then(res => {
            if (res.data.length === 0) {
                this.setData({
                    isShow: true,
                    contents: "暂未发布的商品,快去发布吧...~"
                })
            } else {
                this.setData({
                    isShow: false,
                    contents: ""
                })
            }
            this.setData({
                newGoodsList: res.data
            })

        })
    },
    // 获取已下架商品数据
    getDownGoods() {
        const id = wx.getStorageSync('id')
        db.collection("downs").where({
            id
        }).get().then(res => {
            if (res.data.length === 0) {
                this.setData({
                    isShow: true,
                    contents: "暂未下架过商品...~"
                })
            } else {
                this.setData({
                    isShow: false,
                    contents: ""
                })
            }
            this.setData({
                downGoodsList: res.data
            })

        })
    },
    // 下架商品
    delgoods(e) {
        const param = e.currentTarget.dataset.param;
        wx.showLoading({
            title: '正在下架，请稍候...',
        });
        // 先从 goods 集合获取要下架商品的数据
        db.collection("goods").doc(param).get().then(res => {
            console.log(res.data);
            // 将数据存入 downs 集合
            db.collection("downs").add({
                data: {
                    id: res.data.id,
                    showtime: new Date().toLocaleString(),
                    title: res.data.title,
                    imageIds: res.data.imageIds,
                    newdegree: res.data.newdegree
                }
            }).then(() => {
                this.setData({
                    newGoodsList: res.data
                });
            }).catch(err => {
                console.log(err);
                wx.hideLoading();
                wx.showToast({
                    title: '下架失败，请稍后重试',
                    icon: 'none'
                });
                return;
            });
        }).catch(err => {
            console.log(err);
            wx.hideLoading();
            wx.showToast({
                title: '下架失败，请稍后重试',
                icon: 'none'
            });
            return;
        });
        // 再从 goods 集合删除该商品
        db.collection("goods").doc(param).remove().then(res => {
            wx.hideLoading();
            wx.showToast({
                title: '下架成功!',
            });
            // 直接调用获取数据的方法重新获取数据
            this.getData();
        }).catch(err => {
            console.log(err);
            wx.hideLoading();
            wx.showToast({
                title: '下架失败，请稍后重试',
                icon: 'none'
            });
        });
    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
        this.getData()
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {
        this.getData()
        // 数据加载完成后，停止下拉刷新动画
        wx.stopPullDownRefresh();
        wx.showToast({
            title: '刷新成功!',
            icon: "success"
        })
    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})