const db = wx.cloud.database();

Page({

    /**
     * 页面的初始数据
     */
    data: {
        categoryList: [
            { id: 1, className: "书籍资料" },
            { id: 2, className: "电子设备" },
            { id: 3, className: "学习用品" },
            { id: 4, className: "体育用品" },
            { id: 5, className: "生活用品" },
            { id: 6, className: "服饰配饰" },
            { id: 7, className: "男生专区" },
            { id: 8, className: "女生专区" },
        ],
        newdegreeList: [
            { id: 1, newdegreeName: "全新" },
            { id: 2, newdegreeName: "99新" },
            { id: 3, newdegreeName: "95新" },
            { id: 4, newdegreeName: "9成新" },
            { id: 5, newdegreeName: "8成新" },
        ],
        showDropdown: false,
        selectedCategory: null,
        shownewdegree: false,
        newdegreeName: null,
        title: '',
        issus: '',
        price: '0.00',
        tel: '',
        uploadedImagePaths: [],
        Currenttime: '',

    },
    // 处理图片上传
    async uploadImage() {
        const res = await wx.chooseImage({
          count: 9,
          sizeType: ['original', 'compressed'],
          sourceType: ['album', 'camera'],
        });
        const uploadTasks = res.tempFilePaths.map(filePath => {
          return wx.cloud.uploadFile({
            cloudPath: `images/${Date.now()}-${Math.random()}.jpg`,
            filePath: filePath,
          });
        });
        const results = await Promise.all(uploadTasks);
        console.log('上传结果：', results);
        this.setData({
          uploadedImagePaths: [...this.data.uploadedImagePaths,...results.map(item => item.fileID)],
        });
      },
    deleteImage(e) {
        const index = e.currentTarget.dataset.index;
        // 从数组中删除指定索引的图片路径
        this.data.uploadedImagePaths.splice(index, 1);
        this.setData({
          uploadedImagePaths: this.data.uploadedImagePaths,
        });
      },
    // 将获取过来的数据的time转换成常用的时间格式
    ParseDate() {
        const currentDate = new Date();
        const formatted = currentDate.toString();
        const date = formatted.slice(8, 10)
        const year = formatted.slice(11, 15)
        const hour = formatted.slice(16, 24)
        const month = formatted.slice(4, 7)
        const monthsArr = {
            Jan: '01', Feb: '02', Mar: '03', Apr: '04', May: '05', Jun: '06',
            Jul: '07', Aug: '08', Sep: '09', Oct: '10', Nov: '11', Dec: '12'
        };
        console.log(`${year}.${monthsArr[month]}.${date}  ${hour}`)
        this.setData({
            Currenttime: `${year}.${monthsArr[month]}.${date}  ${hour}`
        })
    },
    // 处理商品信息提交
   // 处理商品信息提交
async addData(e) {
    const formData = e.detail.value;
    const currentDate = new Date();
    const id = wx.getStorageSync('id');
    const avator = wx.getStorageSync('avator');
    const uname = wx.getStorageSync('uname');
    this.ParseDate();

    // 检查各项是否为空
    if (!formData.title ||!formData.issus ||!formData.price ||!this.data.selectedCategory ||!this.data.selectednewdegree ||!formData.tel) {
        wx.showToast({
            title: '所有项均不为空',
            icon: 'error'
        });
        return;
    }
    // 如果 price 不是数字类型，尝试将其转换为数字
    if (typeof formData.price!== 'number') {
        formData.price = parseFloat(formData.price) || 0;
    }
    // 将数字格式化为固定小数位数的字符串
    formData.price = formData.price.toFixed(2);

    // goodsInfo 对象接收商品的数据，并添加审核状态为 pending
    const goodsInfo = {
        title: formData.title,
        description: formData.issus,
        price: formData.price,
        category: this.data.selectedCategory,
        newdegree: this.data.selectednewdegree,
        tel: formData.tel,
        hit: 0,
        time: currentDate,
        showtime: this.data.Currenttime,
        imageIds: this.data.uploadedImagePaths || [],
        id: id,
        avatorImg: avator,
        username: uname,
        status: 'pending', // 添加审核状态字段
    };
    await db.collection('goods').add({
        data: goodsInfo,
    });
    wx.showToast({
        title: '商品已提交审核，等待管理员审核。',
        icon: 'success',
    });
    // 清空表单数据
    this.setData({
        title: '',
        issus: '',
        price: '0.00',
        selectedCategory: null,
        showDropdown: false,
        selectednewdegree: null,
        shownewdegree: false,
        tel: '',
        uploadedImagePaths: [],
    });
},
    // 处理分类下拉菜单的切换
    toggleDropdown() {
        this.setData({
            showDropdown: !this.data.showDropdown,
        });
    },
    selectClass(e) {
        const category = e.currentTarget.dataset.param;
        this.setData({
            selectedCategory: category,
            showDropdown: false,
        });
    },
    // 处理新旧程度下拉菜单的切换
    togglenewdegree() {
        this.setData({
            shownewdegree: !this.data.shownewdegree,
        });
    },
    selectnewdegree(e) {
        const newdegree = e.currentTarget.dataset.params;
        this.setData({
            selectednewdegree: newdegree,
            shownewdegree: false,
        });
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        const telphone = wx.getStorageSync('tel')
        this.setData({
            tel: telphone
        })
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
        const telphone = wx.getStorageSync('tel')
        const id = wx.getStorageSync('id')
        this.setData({
            tel: telphone
        })
        if (!id) {
            wx.showToast({
                title: '请先登录!',
                icon: 'error'
            })
            setTimeout(() => {
                wx.switchTab({
                    url: '/pages/center/center',
                })
            }, 1000)
        }
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
})