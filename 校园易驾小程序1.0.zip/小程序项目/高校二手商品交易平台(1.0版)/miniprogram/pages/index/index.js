const hitFn = require("../../utils/index")
const db = wx.cloud.database();

Page({
    data: {
        //九宫格数据
        list: [],
        // 轮播图数据
        tus: [],
        // 商品列表数据
        goodsList: [],
        page: 2, // 当前页码
        pageSize: 2, // 每页条数
        prompt: false,  //是否显示已经到底了
        islogin: Boolean, //判断是否登录
        showFloatButtons: false,
    },

    // 处理客服消息回调
    handleContact(e) {
        console.log('客服消息回调', e);
        // 可以在这里记录用户点击了客服按钮
        wx.reportAnalytics('customer_service_click', {
            button_type: 'kefu_button'
        });
    },

    // 点击或聚焦输入框时触发的逻辑
    toSearch() {
        console.log('跳转到搜索页面')
        wx.navigateTo({
            url: "/pages/search/search",
        })
    },

    // 跳转到catagory页面的逻辑
    toCategory(event) {
        const params = +event.currentTarget.dataset.param;
        console.log('跳转到分类页面，参数:', params)
        if (!params) {
            wx.setStorageSync('paramKey', "1");
            wx.switchTab({
                url: '/pages/category/category'
            })
        } else {
            wx.setStorageSync('paramKey', params);
            wx.switchTab({
                url: '/pages/category/category'
            })
        }
    },

    // 跳转到详情页面的逻辑
    toDetail(event) {
        const goods_id = event.currentTarget.dataset.param;
        console.log('跳转到详情页面，商品ID:', goods_id)
        hitFn.updateHit(this.data.islogin, goods_id)
    },

    // 触底加载数据
    loadProducts() {
        console.log('触底加载数据，当前页码:', this.data.page)
        db.collection('goods')
            .skip((this.data.page - 1) * this.data.pageSize)
            .limit(this.data.pageSize)
            .get({
                success: res => {
                    console.log('加载商品数据成功，数量:', res.data.length)
                    const newGoodsList = this.data.goodsList.concat(res.data);
                    this.setData({
                        goodsList: newGoodsList,
                        page: this.data.page + 1,
                    });

                    if (res.data.length > 0) {
                        this.findEvent();
                        this.setData({
                            prompt: false
                        })
                    } else {
                        console.log('没有更多数据了')
                        this.setData({
                            prompt: true
                        })
                    }
                },
                fail: err => {
                    console.error('加载商品数据失败:', err)
                },
            });
    },

    // 数据加载事件
    findEvent: function () {
        console.log('显示加载中提示')
        wx.showLoading({
            title: "数据加载中..."
        })
        setTimeout(function () {
            wx.hideLoading()
            console.log('隐藏加载提示')
        }, 200)
    },

    // 拨打电话逻辑
    tels: function () {
        console.log('拨打电话')
        wx.makePhoneCall({
            phoneNumber: '1234-2384-0000-11',
        })
    },

    // 获取商品数据逻辑
    getData() {
        console.log('获取初始商品数据')
        db.collection("goods")
            .limit(2)
            .get()
            .then(res => {
                console.log('初始商品数据获取成功')
                const goodsList = res.data;
                this.setData({
                    goodsList,
                });
            })
            .catch(err => {
                console.error('初始商品数据获取失败:', err)
            });
    },

    // 获取页面数据
    getPageData() {
        console.log('获取页面数据（轮播图和九宫格）')
        // 获取轮播图数据
        db.collection("lunbotus").get().then(res => {
            console.log('轮播图数据获取成功，数量:', res.data.length)
            this.setData({
                tus: res.data
            })
        }).catch(err => {
            console.error('轮播图数据获取失败:', err)
        })
        
        // 获取九宫格数据
        db.collection("jiugongges").get().then(res => {
            console.log('九宫格数据获取成功，数量:', res.data.length)
            this.setData({
                list: res.data
            })
        }).catch(err => {
            console.error('九宫格数据获取失败:', err)
        })
    },

    // 显示/隐藏浮动按钮
    toggleFloatButtons() {
        console.log('切换浮动按钮显示状态，当前:', this.data.showFloatButtons)
        this.setData({
            showFloatButtons: !this.data.showFloatButtons
        })
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        console.log('页面加载，参数:', options)
        this.findEvent();
        this.getPageData()
        this.getData()
        const islogin = wx.getStorageSync('islogin')
        console.log('登录状态:', islogin)
        this.setData({
            islogin: islogin
        })
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {
        console.log('页面初次渲染完成')
    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
        console.log('页面显示')
        const islogin = wx.getStorageSync('islogin')
        console.log('更新登录状态:', islogin)
        this.setData({
            islogin: islogin
        })
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {
        console.log('页面隐藏')
    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {
        console.log('页面卸载')
    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {
        console.log('用户下拉刷新')
        this.loadProducts();
        wx.stopPullDownRefresh();
        console.log('下拉刷新完成')
    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {
        console.log('页面上拉触底')
        this.loadProducts();
    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {
        console.log('用户点击分享')
        return {
            title: '精品二手车推荐',
            path: '/pages/index/index'
        }
    }
})