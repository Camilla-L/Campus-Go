const cloud = require('wx-server-sdk')
cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

exports.main = async (event, context) => {
  const { msg } = event
  
  console.log('=== 本地聊天云函数开始执行 ===')
  console.log('收到用户消息:', msg)
  
  // 测试消息回复
  if (msg === 'test' || msg === '测试') {
    console.log('收到测试消息，返回测试回复')
    return {
      success: true,
      resmsg: '测试成功！AI客服正常工作。请问您需要什么帮助？'
    }
  }
  
  try {
    // 使用本地智能回复系统
    const response = getLocalResponse(msg)
    console.log('生成回复:', response.resmsg)
    
    return response
  } catch (error) {
    console.error('处理消息时发生错误:', error)
    return {
      success: true,
      resmsg: '抱歉，系统暂时无法处理您的请求。您想了解二手车价格还是车型推荐？'
    }
  }
}

// 本地智能回复系统
function getLocalResponse(msg) {
  const lowerMsg = (msg || '').toLowerCase().trim()
  console.log('分析消息内容:', lowerMsg)
  
  // 问候语识别
  if (lowerMsg.includes('你好') || lowerMsg.includes('您好') || 
      lowerMsg.includes('嗨') || lowerMsg.includes('hello') || 
      lowerMsg.includes('hi') || lowerMsg === '在吗') {
    return {
      success: true,
      resmsg: '您好！欢迎咨询二手车信息，我是AI客服，很高兴为您服务！有什么可以帮您的？'
    }
  }
  
  // 价格相关
  if (lowerMsg.includes('价格') || lowerMsg.includes('多少钱') || 
      lowerMsg.includes('价位') || lowerMsg.includes('报价') ||
      lowerMsg.includes('贵不贵') || lowerMsg.includes('便宜')) {
    return {
      success: true,
      resmsg: '车辆价格因车型、车况、年份和配置而异。\n\n🚗 经济型（5-10万）：丰田卡罗拉、本田飞度、大众POLO\n🚙 中级车（10-20万）：本田雅阁、丰田凯美瑞、大众帕萨特\n🏎 豪华型（20万以上）：宝马3系、奔驰C级、奥迪A4\n\n您对什么车型感兴趣？我可以给您更具体的报价参考。'
    }
  }
  
  // 品牌相关
  if (lowerMsg.includes('品牌') || lowerMsg.includes('什么车') || 
      lowerMsg.includes('车型') || lowerMsg.includes('车款') ||
      lowerMsg.includes('推荐') || lowerMsg.includes('选什么')) {
    return {
      success: true,
      resmsg: '我们提供多种品牌的优质二手车：\n\n✅ 日系：丰田、本田、日产（省油耐用）\n✅ 德系：大众、宝马、奔驰、奥迪（操控性好）\n✅ 美系：福特、别克、雪佛兰（舒适性强）\n✅ 国产：吉利、长城、长安（性价比高）\n\n您更关注油耗、空间、动力还是保值率？我可以为您推荐合适的车型。'
    }
  }
  
  // 车况质量
  if (lowerMsg.includes('车况') || lowerMsg.includes('质量') || 
      lowerMsg.includes('检测') || lowerMsg.includes('事故') ||
      lowerMsg.includes('泡水') || lowerMsg.includes('火烧')) {
    return {
      success: true,
      resmsg: '请您放心！所有车辆都经过我们的专业检测：\n\n🔍 128项全面检测\n🔍 确保无重大事故\n🔍 无火烧、无泡水\n🔍 提供详细检测报告\n🔍 7天无理由退换\n\n我们会提供完整的车辆历史报告，让您买得放心！'
    }
  }
  
  // 联系方式
  if (lowerMsg.includes('联系') || lowerMsg.includes('电话') || 
      lowerMsg.includes('地址') || lowerMsg.includes('怎么去') ||
      lowerMsg.includes('门店') || lowerMsg.includes('在哪')) {
    return {
      success: true,
      resmsg: '📞 客服热线：400-123-4567\n🕘 工作时间：9:00-18:00（全年无休）\n📍 门店地址：北京市朝阳区汽车产业园88号\n🚗 免费接送：可预约免费上门接驾服务\n\n需要我帮您预约看车时间吗？'
    }
  }
  
  // 优惠活动
  if (lowerMsg.includes('优惠') || lowerMsg.includes('活动') || 
      lowerMsg.includes('折扣') || lowerMsg.includes('便宜') ||
      lowerMsg.includes('促销') || lowerMsg.includes('降价')) {
    return {
      success: true,
      resmsg: '🎉 当前优惠活动：\n\n✨ 新春特惠：部分车型立减10000元\n✨ 金融方案：首付30%，3年免息\n✨ 赠送礼包：购车即送全年保养\n✨ 置换补贴：旧车置换最高补贴5000元\n✨ 推荐有礼：推荐朋友购车得1000元红包\n\n您想了解哪款车的具体优惠？'
    }
  }
  
  // 具体品牌查询
  const brandKeywords = {
    '丰田': ['丰田', 'toyota', '卡罗拉', '凯美瑞', 'rav4', '汉兰达'],
    '本田': ['本田', 'honda', '雅阁', '思域', 'crv', '飞度'],
    '大众': ['大众', 'volkswagen', '帕萨特', '迈腾', '朗逸', '途观'],
    '宝马': ['宝马', 'bmw', '3系', '5系', 'x1', 'x3'],
    '奔驰': ['奔驰', 'benz', 'mercedes', 'c级', 'e级', 'glc'],
    '奥迪': ['奥迪', 'audi', 'a4', 'a6', 'q3', 'q5']
  }
  
  for (const [brand, keywords] of Object.entries(brandKeywords)) {
    if (keywords.some(keyword => lowerMsg.includes(keyword))) {
      return {
        success: true,
        resmsg: `您想了解${brand}的二手车信息吗？${brand}车型以${getBrandFeature(brand)}著称。\n\n热门${brand}车型：\n${getBrandModels(brand)}\n\n您对哪款车型特别感兴趣？我可以为您提供详细的车源信息和价格参考。`
      }
    }
  }
  
  // 感谢语
  if (lowerMsg.includes('谢谢') || lowerMsg.includes('感谢') || 
      lowerMsg.includes('thx') || lowerMsg.includes('3q')) {
    return {
      success: true,
      resmsg: '不用客气！很高兴能为您服务。如果还有其他问题，随时问我哦！祝您选到心仪的座驾！🚗💨'
    }
  }
  
  // 默认回复
  return {
    success: true,
    resmsg: '感谢咨询！我是二手车AI客服，可以帮您：\n\n🔹 查询车辆价格\n🔹 推荐合适车型\n🔹 介绍车况检测\n🔹 提供优惠信息\n🔹 解答购车疑问\n\n您具体想了解什么内容呢？'
  }
}

// 获取品牌特点
function getBrandFeature(brand) {
  const features = {
    '丰田': '省油耐用、保值率高',
    '本田': '发动机技术好、空间利用率高',
    '大众': '底盘扎实、操控性好',
    '宝马': '操控精准、驾驶乐趣强',
    '奔驰': '舒适豪华、内饰精致',
    '奥迪': '科技感强、四驱系统优秀'
  }
  return features[brand] || '品质可靠'
}

// 获取品牌车型
function getBrandModels(brand) {
  const models = {
    '丰田': '∙ 卡罗拉（10-15万）\n∙ 凯美瑞（15-25万）\n∙ RAV4荣放（18-28万）\n∙ 汉兰达（25-35万）',
    '本田': '∙ 飞度（8-12万）\n∙ 思域（12-18万）\n∙ 雅阁（18-28万）\n∙ CR-V（20-30万）',
    '大众': '∙ 朗逸（10-15万）\n∙ 帕萨特（18-28万）\n∙ 迈腾（20-30万）\n∙ 途观（22-32万）',
    '宝马': '∙ 3系（25-40万）\n∙ 5系（40-60万）\n∙ X1（25-35万）\n∙ X3（40-55万）',
    '奔驰': '∙ C级（30-45万）\n∙ E级（45-65万）\n∙ GLC（40-55万）\n∙ GLB（35-45万）',
    '奥迪': '∙ A4L（28-42万）\n∙ A6L（40-60万）\n∙ Q3（25-35万）\n∙ Q5L（40-55万）'
  }
  return models[brand] || '∙ 多款车型可选，价格区间丰富'
}