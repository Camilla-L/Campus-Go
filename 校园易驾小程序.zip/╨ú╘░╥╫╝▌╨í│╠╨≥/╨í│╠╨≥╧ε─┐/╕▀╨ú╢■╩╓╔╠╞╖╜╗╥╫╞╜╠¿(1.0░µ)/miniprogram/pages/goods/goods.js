const db = wx.cloud.database()
const app = getApp()

Page({
  data: {
    activeNav: 'buy', // 默认显示买车区
    goodsList: [],
    isLoading: true,
    hasMore: true,
    page: 1,
    pageSize: 10,
    categoryMapping: {
      'buy': ['卖车'],      // 买车区显示"卖车"类商品
      'sell': ['收车'],     // 卖车区显示"收车"类商品
      'rent': ['租车', '出租'], // 租车区显示"租车"和"出租"类商品
      'service': ['质检', '维修'] // 售后区显示"质检"和"维修"类商品
    }
  },

  onLoad: function(options) {
    if (options.nav) {
      this.setData({
        activeNav: options.nav
      })
    }
    this.loadGoods()
  },

  onShow: function() {
    this.setData({
      islogin: wx.getStorageSync('islogin')
    })
  },

  // 加载商品数据
  loadGoods: function() {
    if (this.data.isLoading || !this.data.hasMore) return
    
    this.setData({ isLoading: true })
    
    const categories = this.data.categoryMapping[this.data.activeNav]
    
    db.collection('goods')
      .where({
        category: db.command.in(categories),
        status: 'on_sale' // 只显示在售商品
      })
      .orderBy('postTime', 'desc')
      .skip((this.data.page - 1) * this.data.pageSize)
      .limit(this.data.pageSize)
      .get()
      .then(res => {
        const newList = res.data
        const hasMore = newList.length === this.data.pageSize
        
        this.setData({
          goodsList: this.data.page === 1 ? newList : [...this.data.goodsList, ...newList],
          isLoading: false,
          hasMore: hasMore
        })
      })
      .catch(err => {
        console.error('获取商品失败:', err)
        this.setData({ isLoading: false })
        wx.showToast({
          title: '加载失败',
          icon: 'none'
        })
      })
  },

  // 切换导航
  switchNav: function(e) {
    const navId = e.currentTarget.dataset.id
    if (this.data.activeNav === navId) return
    
    this.setData({
      activeNav: navId,
      page: 1,
      goodsList: [],
      hasMore: true
    }, () => {
      this.loadGoods()
    })
  },

  // 加载更多
  loadMore: function() {
    if (this.data.isLoading || !this.data.hasMore) return
    
    this.setData({
      page: this.data.page + 1
    }, () => {
      this.loadGoods()
    })
  },

  // 跳转到详情页
  toDetail: function(e) {
    const goods_id = e.currentTarget.dataset.id
    const hitFn = require("../../utils/index")
    hitFn.updateHit(this.data.islogin, goods_id)
    
    wx.navigateTo({
      url: `/pages/detail/detail?goods_id=${goods_id}`
    })
  },

  // 格式化时间
  formatTime: function(dateString) {
    if (!dateString) return ''
    
    const date = new Date(dateString)
    const now = new Date()
    const diff = now - date
    const minutes = Math.floor(diff / (1000 * 60))
    const hours = Math.floor(diff / (1000 * 60 * 60))
    const days = Math.floor(diff / (1000 * 60 * 60 * 24))
    
    if (minutes < 1) {
      return '刚刚'
    } else if (minutes < 60) {
      return `${minutes}分钟前`
    } else if (hours < 24) {
      return `${hours}小时前`
    } else if (days < 7) {
      return `${days}天前`
    } else {
      return `${date.getMonth() + 1}月${date.getDate()}日`
    }
  }
})