const db = wx.cloud.database()
Page({

    /**
     * 页面的初始数据
     */
    data: {
        orderList: [],
        isLoading: true,
        isShow: false,
        contents: "暂无订单数据",
        selectedTab: 'all', // 全部订单
        activeMenuIndex: -1, // 当前激活的菜单索引
        tabs: [
            { key: 'all', name: '全部订单' },
            { key: 'pending', name: '待处理' },
            { key: 'shipped', name: '已发货' },
            { key: 'completed', name: '已完成' },
            { key: 'cancelling', name: '中止中' }
        ]
    },

    // 切换订单状态标签
    switchTab(e) {
        const tab = e.currentTarget.dataset.tab;
        this.setData({
            selectedTab: tab,
            isLoading: true,
            activeMenuIndex: -1 // 关闭所有菜单
        });
        this.getOrders(tab);
    },

    // 获取订单数据
    getOrders(status = 'all') {
        const sellerId = wx.getStorageSync('id');
        if (!sellerId) {
            this.setData({
                isLoading: false,
                isShow: true,
                contents: "请先登录"
            });
            return;
        }

        let query = { sellerId: sellerId };
        
        // 根据状态筛选
        if (status !== 'all') {
            query.status = status;
        }

        db.collection("orders")
            .where(query)
            .orderBy('createTime', 'desc')
            .get()
            .then(res => {
                if (res.data.length === 0) {
                    this.setData({
                        isShow: true,
                        contents: "暂无订单数据",
                        orderList: [],
                        isLoading: false
                    });
                } else {
                    this.setData({
                        orderList: res.data,
                        isShow: false,
                        isLoading: false
                    });
                }
            })
            .catch(err => {
                console.error("获取订单失败", err);
                this.setData({
                    isLoading: false,
                    isShow: true,
                    contents: "获取订单失败，请重试"
                });
                wx.showToast({
                    title: '获取订单失败',
                    icon: 'none'
                });
            });
    },

    // 查看商品详情
    viewGoodsDetail(e) {
        const goodsId = e.currentTarget.dataset.id;
        wx.navigateTo({
            url: `/pages/detail/detail?id=${goodsId}`
        });
    },

    // 查看订单详情
    viewOrderDetail(e) {
        const orderId = e.currentTarget.dataset.id;
        this.closeMenu(); // 关闭菜单
        wx.navigateTo({
            url: `/pages/orderDetail/orderDetail?id=${orderId}&role=seller`
        });
    },

    // 联系买家 - 跳转到contact页面
    contactBuyer(e) {
        const buyerId = e.currentTarget.dataset.buyerid;
        const orderId = e.currentTarget.dataset.orderid;
        this.closeMenu(); // 关闭菜单
        
        wx.navigateTo({
            url: `/pages/contact/contact?targetId=${buyerId}&orderId=${orderId}`
        });
    },

    // 格式化时间
    formatTime(dateString) {
        if (!dateString) return '';
        
        const date = new Date(dateString);
        const now = new Date();
        const diff = now - date;
        const minutes = Math.floor(diff / (1000 * 60));
        const hours = Math.floor(diff / (1000 * 60 * 60));
        const days = Math.floor(diff / (1000 * 60 * 60 * 24));
        
        if (minutes < 1) {
            return '刚刚';
        } else if (minutes < 60) {
            return `${minutes}分钟前`;
        } else if (hours < 24) {
            return `${hours}小时前`;
        } else if (days < 7) {
            return `${days}天前`;
        } else {
            return `${date.getMonth() + 1}月${date.getDate()}日 ${date.getHours()}:${date.getMinutes()}`;
        }
    },

    // 中止订单函数
    cancelOrder(e) {
        const orderId = e.currentTarget.dataset.id;
        const that = this;
        this.closeMenu(); // 关闭菜单
        
        wx.showModal({
            title: '确认中止',
            content: '确定要中止这笔订单吗？系统将向买家发送中止申请',
            success: async function(res) {
                if (res.confirm) {
                    wx.showLoading({
                        title: '处理中...',
                    });
                    
                    try {
                        // 更新订单状态为"cancelling"（中止中）
                        await db.collection("orders").doc(orderId).update({
                            data: {
                                status: 'cancelling',
                                cancelTime: new Date().toISOString()
                            }
                        });
                        
                        // 发送消息通知买家
                        const orderRes = await db.collection("orders").doc(orderId).get();
                        const order = orderRes.data;
                        
                        await db.collection("messages").add({
                            data: {
                                type: 'order_cancel',
                                title: '订单中止申请',
                                content: `卖家申请中止订单 ${order.orderNumber}，请及时处理`,
                                senderId: wx.getStorageSync('id'),
                                senderName: wx.getStorageSync('uname'),
                                receiverId: order.buyerId,
                                relatedId: orderId,
                                isRead: false,
                                createTime: new Date().toISOString()
                            }
                        });
                        
                        wx.hideLoading();
                        wx.showToast({
                            title: '已发送中止申请',
                            icon: 'success'
                        });
                        
                        // 刷新订单列表
                        that.getOrders(that.data.selectedTab);
                    } catch (error) {
                        console.error('中止订单失败:', error);
                        wx.hideLoading();
                        wx.showToast({
                            title: '操作失败，请重试',
                            icon: 'none'
                        });
                    }
                }
            }
        });
    },

    // 删除订单函数（当中止申请被买家同意后）
    deleteOrder(e) {
        const orderId = e.currentTarget.dataset.id;
        const that = this;
        this.closeMenu(); // 关闭菜单
        
        wx.showModal({
            title: '确认删除',
            content: '确定要删除这笔订单吗？此操作不可恢复',
            success: async function(res) {
                if (res.confirm) {
                    wx.showLoading({
                        title: '删除中...',
                    });
                    
                    try {
                        await db.collection("orders").doc(orderId).remove();
                        
                        wx.hideLoading();
                        wx.showToast({
                            title: '删除成功',
                            icon: 'success'
                        });
                        
                        // 刷新订单列表
                        that.getOrders(that.data.selectedTab);
                    } catch (error) {
                        console.error('删除订单失败:', error);
                        wx.hideLoading();
                        wx.showToast({
                            title: '删除失败，请重试',
                            icon: 'none'
                        });
                    }
                }
            }
        });
    },

    // 更新订单状态
    updateOrderStatus(e) {
        const { id, status } = e.currentTarget.dataset;
        const statusText = {
            'pending': '确认发货',
            'shipped': '确认收货',
            'completed': '已完成'
        }[status] || '处理';

        this.closeMenu(); // 关闭菜单

        wx.showModal({
            title: '确认操作',
            content: `确定要${statusText}吗？`,
            success: async (res) => {
                if (res.confirm) {
                    wx.showLoading({
                        title: '处理中...',
                    });

                    try {
                        let updateData = {};
                        
                        // 根据当前状态确定下一步状态
                        if (status === 'pending') {
                            updateData.status = 'shipped';
                            updateData.shipTime = new Date().toISOString();
                        } else if (status === 'shipped') {
                            updateData.status = 'completed';
                            updateData.completeTime = new Date().toISOString();
                            
                            // 订单完成时，将商品状态改为已售出
                            const orderRes = await db.collection("orders").doc(id).get();
                            if (orderRes.data && orderRes.data.goodsId) {
                                await db.collection("goods").doc(orderRes.data.goodsId).update({
                                    data: {
                                        saleStatus: 'sold'
                                    }
                                });
                            }
                        }

                        await db.collection("orders").doc(id).update({
                            data: updateData
                        });

                        wx.hideLoading();
                        wx.showToast({
                            title: '操作成功',
                            icon: 'success'
                        });

                        // 刷新订单列表
                        this.getOrders(this.data.selectedTab);
                    } catch (error) {
                        console.error('更新订单状态失败:', error);
                        wx.hideLoading();
                        wx.showToast({
                            title: '操作失败，请重试',
                            icon: 'none'
                        });
                    }
                }
            }
        });
    },

    // 切换菜单显示
    toggleMenu(e) {
        const index = e.currentTarget.dataset.index;
        // 微信小程序事件对象没有stopPropagation方法，已移除
        // 使用catchtap绑定事件可以阻止冒泡
        
        this.setData({
            activeMenuIndex: this.data.activeMenuIndex === index ? -1 : index
        });
    },

    // 关闭菜单
    closeMenu() {
        this.setData({
            activeMenuIndex: -1
        });
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
        this.getOrders();
        
        // 监听全局数据变化（用于接收买家对中止申请的响应）
        const that = this;
        wx.onAppShow(function(res) {
            if (getApp().globalData.refreshOrders) {
                that.getOrders(that.data.selectedTab);
                getApp().globalData.refreshOrders = false;
            }
        });
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {
        // 页面显示时刷新数据
        this.getOrders(this.data.selectedTab);
        // 关闭所有菜单
        this.closeMenu();
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {
        // 关闭所有菜单
        this.closeMenu();
    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {
        this.getOrders(this.data.selectedTab);
        wx.stopPullDownRefresh();
    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})