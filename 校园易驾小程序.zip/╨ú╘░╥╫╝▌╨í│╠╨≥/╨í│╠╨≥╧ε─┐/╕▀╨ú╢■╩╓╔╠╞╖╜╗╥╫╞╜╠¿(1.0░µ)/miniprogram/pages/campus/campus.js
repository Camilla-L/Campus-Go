const db = wx.cloud.database()
const _ = db.command

Page({
  data: {
    // 高校选择
    universities: [
      { id: 1, name: '全部' },
      { id: 2, name: '广州大学城' },
      { id: 3, name: '清华大学' },
      { id: 4, name: '北京大学' },
      { id: 5, name: '复旦大学' },
      { id: 6, name: '上海交通大学' }
    ],
    selectedUniversity: '全部',
    showUniversityPicker: false,
    
    // 帖子类型
    postTypes: [
      { id: 1, name: '全部', icon: 'all' },
      { id: 2, name: '动态', icon: 'dynamic' },
      { id: 3, name: '求助', icon: 'help' },
      { id: 4, name: '经验', icon: 'experience' }
    ],
    selectedPostType: '全部',
    
    // 帖子列表
    posts: [],
    hotPosts: [], // 热门帖子
    isLoading: false,
    hasMore: true,
    page: 1,
    pageSize: 10,
    
    // 发布相关
    showPublishPanel: false,
    publishContent: '',
    publishImages: [],
    publishType: '动态',
    isPublishing: false,
    
    // 用户相关
    isLogin: false,
    userInfo: null
  },

  // 选择高校
  selectUniversity(e) {
    const university = e.currentTarget.dataset.university;
    this.setData({
      selectedUniversity: university,
      showUniversityPicker: false,
      page: 1,
      hasMore: true
    });
    this.loadPosts(true);
  },

  // 显示/隐藏高校选择器
  toggleUniversityPicker() {
    this.setData({
      showUniversityPicker: !this.data.showUniversityPicker
    });
  },

  // 选择帖子类型
  selectPostType(e) {
    const type = e.currentTarget.dataset.type;
    this.setData({
      selectedPostType: type,
      page: 1,
      hasMore: true
    });
    this.loadPosts(true);
  },

  // 加载帖子
  async loadPosts(refresh = false) {
    if (this.data.isLoading && !refresh) return;
    this.setData({ isLoading: true });
  
    try {
      let query = db.collection('campus_posts').where({ status: 'published' });
      if (this.data.selectedUniversity !== '全部') {
        query = query.where({ university: this.data.selectedUniversity });
      }
      if (this.data.selectedPostType !== '全部') {
        query = query.where({ type: this.data.selectedPostType });
      }
  
      const res = await query
        .orderBy('createTime', 'desc')
        .skip((this.data.page - 1) * this.data.pageSize)
        .limit(this.data.pageSize)
        .get();
  
      let posts = res.data;
  
      // ⭐ 给每个帖子拉取对应的评论
      for (let i = 0; i < posts.length; i++) {
        const commentsRes = await db.collection('campus_comments')
          .where({ postId: posts[i]._id })
          .orderBy('createTime', 'desc')
          .get();
        posts[i].comments = commentsRes.data; // 添加评论数组
      }
  
      const newPosts = refresh ? posts : [...this.data.posts, ...posts];
  
      this.setData({
        posts: newPosts,
        isLoading: false,
        hasMore: res.data.length === this.data.pageSize
      });
  
      if (refresh) {
        this.loadHotPosts();
      }
    } catch (err) {
      console.error('加载帖子失败:', err);
      this.setData({ isLoading: false });
      wx.showToast({ title: '加载失败', icon: 'none' });
    }
  },
  onViewAllComments(e) {
    const post = e.detail.post;
    wx.navigateTo({
      url: `/pages/postDetail/postDetail?id=${post._id}`
    });
  },  

  // 加载热门帖子
  async loadHotPosts() {
    try {
      let query = db.collection('campus_posts').where({
        status: 'published',
        likeCount: _.gt(10) // 点赞数大于10的认为是热门
      });
      
      // 按高校筛选
      if (this.data.selectedUniversity !== '全部') {
        query = query.where({
          university: this.data.selectedUniversity
        });
      }
      
      const res = await query
        .orderBy('likeCount', 'desc')
        .limit(5)
        .get();
      
      this.setData({
        hotPosts: res.data
      });
    } catch (err) {
      console.error('加载热门帖子失败:', err);
    }
  },

  // 显示发布面板
  showPublish() {
    const isLogin = wx.getStorageSync('islogin');
    if (!isLogin) {
      wx.showToast({
        title: '请先登录',
        icon: 'none'
      });
      setTimeout(() => {
        wx.navigateTo({
          url: '/pages/login/login'
        });
      }, 1000);
      return;
    }
    
    this.setData({
      showPublishPanel: true,
      publishContent: '',
      publishImages: [],
      publishType: '动态'
    });
  },

  // 隐藏发布面板
  hidePublish() {
    this.setData({ showPublishPanel: false });
  },

  // 选择发布类型
  selectPublishType(e) {
    const type = e.currentTarget.dataset.type;
    this.setData({ publishType: type });
  },

  // 输入发布内容
  onPublishInput(e) {
    this.setData({ publishContent: e.detail.value });
  },

  // 选择图片
  async chooseImage() {
    try {
      const res = await wx.chooseImage({
        count: 9 - this.data.publishImages.length,
        sizeType: ['compressed'],
        sourceType: ['album', 'camera']
      });
      
      this.setData({
        publishImages: [...this.data.publishImages, ...res.tempFilePaths]
      });
    } catch (err) {
      console.error('选择图片失败:', err);
    }
  },

  // 删除图片
  removeImage(e) {
    const index = e.currentTarget.dataset.index;
    const images = [...this.data.publishImages];
    images.splice(index, 1);
    this.setData({ publishImages: images });
  },

  // 发布帖子
  async submitPost() {
    const content = this.data.publishContent.trim();
    if (!content) {
      wx.showToast({
        title: '请输入内容',
        icon: 'none'
      });
      return;
    }
    
    this.setData({ isPublishing: true });
    
    try {
      // 上传图片
      let imageUrls = [];
      for (const tempPath of this.data.publishImages) {
        const uploadRes = await wx.cloud.uploadFile({
          cloudPath: `campus_posts/${Date.now()}-${Math.random().toString(36).substr(2, 9)}.jpg`,
          filePath: tempPath
        });
        imageUrls.push(uploadRes.fileID);
      }
      
      // 获取用户信息
      const userInfo = {
        id: wx.getStorageSync('id'),
        name: wx.getStorageSync('uname'),
        avatar: wx.getStorageSync('avator')
      };
      
      // 保存帖子
      const postData = {
        content: content,
        images: imageUrls,
        type: this.data.publishType,
        university: this.data.selectedUniversity === '全部' ? '广州大学城' : this.data.selectedUniversity,
        author: userInfo,
        likeCount: 0,
        commentCount: 0,
        viewCount: 0,
        status: 'published',
        createTime: db.serverDate(),
        updateTime: db.serverDate()
      };
      
      await db.collection('campus_posts').add({
        data: postData
      });
      
      wx.showToast({
        title: '发布成功',
        icon: 'success'
      });
      
      this.setData({
        showPublishPanel: false,
        isPublishing: false
      });
      
      // 刷新帖子列表
      this.loadPosts(true);
    } catch (err) {
      console.error('发布失败:', err);
      this.setData({ isPublishing: false });
      wx.showToast({
        title: '发布失败',
        icon: 'none'
      });
    }
  },

  // 点赞帖子
  async likePost(e) {
    const isLogin = wx.getStorageSync('islogin');
    if (!isLogin) {
      wx.showToast({
        title: '请先登录',
        icon: 'none'
      });
      return;
    }
    
    const postId = e.currentTarget.dataset.id;
    const userId = wx.getStorageSync('id');
    
    try {
      // 检查是否已点赞
      const likeRecord = await db.collection('campus_likes').where({
        postId: postId,
        userId: userId
      }).get();
      
      if (likeRecord.data.length > 0) {
        // 已点赞，取消点赞
        await db.collection('campus_likes').doc(likeRecord.data[0]._id).remove();
        await db.collection('campus_posts').doc(postId).update({
          data: {
            likeCount: _.inc(-1)
          }
        });
      } else {
        // 未点赞，添加点赞
        await db.collection('campus_likes').add({
          data: {
            postId: postId,
            userId: userId,
            createTime: db.serverDate()
          }
        });
        await db.collection('campus_posts').doc(postId).update({
          data: {
            likeCount: _.inc(1)
          }
        });
      }
      
      // 更新UI
      this.loadPosts(true);
    } catch (err) {
      console.error('操作失败:', err);
    }
  },
    onCommentPost(e) {
      const { postId, content, replyTo } = e.detail;
      const userInfo = this.data.userInfo;

      if (!this.data.isLogin) {
        wx.showToast({ title: '请先登录', icon: 'none' });
        return;
      }

      // 往数据库插入评论
      db.collection('campus_comments').add({
        data: {
          postId: postId,
          content: content,
          replyTo: replyTo || null,
          author: userInfo,
          createTime: db.serverDate()
        }
      }).then(() => {
        wx.showToast({ title: '评论成功', icon: 'success' });

        // 更新帖子评论数
        db.collection('campus_posts').doc(postId).update({
          data: { commentCount: _.inc(1) }
        });

        // 立即更新UI - 找到对应的帖子并添加新评论
        const newPosts = this.data.posts.map(post => {
          if (post._id === postId) {
            // 创建新评论对象
            const newComment = {
              postId: postId,
              content: content,
              replyTo: replyTo || null,
              author: userInfo,
              createTime: new Date(),
              // 添加临时ID，避免渲染问题
              _id: 'temp_' + Date.now()
            };
            
            // 添加到评论列表开头
            post.comments = post.comments || [];
            post.comments.unshift(newComment);
            post.commentCount += 1;
          }
          return post;
        });

        this.setData({ posts: newPosts });

      }).catch(err => {
        console.error('评论失败:', err);
        wx.showToast({ title: '评论失败', icon: 'none' });
      });
    },
  onLikePost(e) {
    const postId = e.detail.postId;   // 这里用 postId
    if (!postId) {
      console.error('onLikePost 没拿到 postId:', e);
      return;
    }
    this.likePost({ currentTarget: { dataset: { id: postId } } });
  },
  
  onSharePost(e) {
    const post = e.detail.post;
    console.log('分享帖子:', post._id);
    wx.showShareMenu({ withShareTicket: true });
  },
  onShareAppMessage(e) {
    // 如果是从按钮触发
    if (e.from === 'button') {
      const post = e.target.dataset.post; // 拿到 post
      return {
        title: post.content.slice(0, 20), // 分享标题
        path: `/pages/postDetail/postDetail?id=${post._id}`, // 分享路径
        imageUrl: post.images && post.images.length > 0 ? post.images[0] : '' // 分享封面图
      }
    }

    // 默认分享
    return {
      title: '校园论坛',
      path: '/pages/campus/campus'
    }
  },
  
  // 查看帖子详情
  viewPostDetail(e) {
    const postId = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: `/pages/postDetail/postDetail?id=${postId}`
    });
  },

  // 下拉刷新
  onPullDownRefresh() {
    this.loadPosts(true);
    wx.stopPullDownRefresh();
  },

  // 上拉加载更多
  onReachBottom() {
    if (!this.data.hasMore || this.data.isLoading) return;
    
    this.setData({
      page: this.data.page + 1
    });
    this.loadPosts();
  },

  // 页面加载
  onLoad() {
    this.checkLoginStatus();
    this.loadPosts(true);
    
    // 监听帖子变化
    db.collection('campus_posts').watch({
      onChange: this.loadPosts.bind(this, true),
      onError: err => console.error('监听失败:', err)
    });
  },

  // 检查登录状态
  checkLoginStatus() {
    const isLogin = wx.getStorageSync('islogin');
    const userInfo = {
      id: wx.getStorageSync('id'),
      name: wx.getStorageSync('uname'),
      avatar: wx.getStorageSync('avator')
    };
    
    this.setData({
      isLogin: isLogin,
      userInfo: isLogin ? userInfo : null
    });
  },

  // 页面显示
  onShow() {
    this.checkLoginStatus();
  }
});