const db = wx.cloud.database()
Page({

    /**
     * 页面的初始数据
     */
    data: {
        isLogin: false,
        uname: 'xxxxx',
        userId: 'xxxx',
        avator:'https://img0.baidu.com/it/u=1240274933,2284862568&fm=253&fmt=auto&app=138&f=PNG?w=180&h=180',
        postNumber:0,
        soldNumber:0,
        unreadCount:0,
        messageIconLeft: 0, 
        messageIconTop: 0,
        isDragging: false,    
        isMoved: false,
        isMessageIconShaking: false, 
        messageIconStartX: 0, 
        messageIconStartY: 0,
        windowWidth: 0, 
        windowHeight: 0
    },
    onLogin() {
        wx.navigateTo({
            url: '/pages/login/login',
        })
    },
    //   跳转到个人信息页面
    toPerson() {
        wx.navigateTo({
          url: '/pages/person/person',
        })
    },
    // 跳转到消息页面
    toMessage() {
      // 停止摇晃动画
      this.setData({
          isMessageIconShaking: false
      });
      
      wx.navigateTo({
          url: '/pages/message/message',
      })
  },
    // 修改登录状态的逻辑
    taggleLogin(){
        const id = wx.getStorageSync("id")
        const userId = wx.getStorageSync('userId')
        const avator = wx.getStorageSync('avator')
        const uname =  wx.getStorageSync('uname')
        // console.log("身份认证", id)
        if (id) {
            this.setData({
                isLogin: true,
                userId,
                avator,
                uname
            })
        }else{
            this.setData({
                isLogin: false,
                userId:'xxxx',
                avator:"https://img0.baidu.com/it/u=1240274933,2284862568&fm=253&fmt=auto&app=138&f=PNG?w=180&h=180",
                uname:'xxxxx'
            })
        }
    },
    // 跳转到发布的商品页面
    toTrand(){
        wx.navigateTo({
          url: '/pages/trand/trand',
        })
    },
    // 跳转到卖出的商品页面
    toSaled() {
      wx.navigateTo({
          url: '/pages/saled/saled',
      })
  },
    // 跳转到买的商品页面
    toBuy() {
      wx.navigateTo({
        url: '/pages/buy/buy',
      })
    },
    // 获取发布的商品个数（包括在售和已下架）
    getCount(){ 
        const id = wx.getStorageSync('id')
        // 同时查询goods和downs集合
        const goodsPromise = db.collection("goods").where({userId: id}).count()
        const downsPromise = db.collection("downs").where({userId: id}).count()
        
        Promise.all([goodsPromise, downsPromise]).then(res => {
            const total = res[0].total + res[1].total
            this.setData({
                postNumber: total
            })
        }).catch(err => {
            console.error("统计商品数量失败", err)
        })
    },
    // 获取卖出的商品数量
    getSoldCount() {
      const sellerId = wx.getStorageSync('id');
      if (!sellerId) return;
      
      db.collection("orders").where({
          sellerId: sellerId
      }).count().then(res => {
          this.setData({
              soldNumber: res.total
          });
      }).catch(err => {
          console.error("获取卖出商品数量失败", err);
      });
  },
    // 获取未读消息数量
    getUnreadCount() {
      const userId = wx.getStorageSync('id');
      if (!userId) return;
      
      db.collection("messages").where({
          receiverId: userId,
          isRead: false
      }).count().then(res => {
          this.setData({
              unreadCount: res.total
          });
          
          // 如果有未读消息，启动摇晃动画
          if (res.total > 0) {
              this.setData({
                  isMessageIconShaking: true
              });
          }
      }).catch(err => {
          console.error("获取未读消息数量失败", err);
      });
  },
  
  // 悬浮图标触摸事件处理
  onMessageIconTouchStart(e) {
      // 记录初始触摸位置和图标位置
      this.setData({
          messageIconStartX: e.touches[0].clientX,
          messageIconStartY: e.touches[0].clientY,
          isDragging: true,
          isMoved: false,
      });
      
      // 停止摇晃动画
      this.setData({
          isMessageIconShaking: false
      });
      return false;
  },
  
  onMessageIconTouchMove(e) {
    const t = e.touches[0];
    const startX = this.data.messageIconStartX;
    const startY = this.data.messageIconStartY;
    const dx = t.clientX - startX;
    const dy = t.clientY - startY;
    // 小阈值判断为拖动
    if (Math.abs(dx) > 3 || Math.abs(dy) > 3) {
      this.setData({ isMoved: true });
    }
  
    let newLeft = this.data.messageIconLeft + dx;
    let newTop  = this.data.messageIconTop  + dy;
  
    // 限制范围（注意这里的 100 要和图标宽度对应）
    newLeft = Math.max(0, Math.min(newLeft, this.data.windowWidth - 100));
    newTop  = Math.max(0, Math.min(newTop, this.data.windowHeight - 100));
  
    this.setData({
      messageIconLeft: newLeft,
      messageIconTop: newTop,
      messageIconStartX: t.clientX,
      messageIconStartY: t.clientY
    });
  },
  
  onMessageIconTouchEnd(e) {
    // 取消拖拽态（隐藏遮罩）
    this.setData({ isDragging: false });
  
    // 吸附逻辑（水平吸边）
    const { windowWidth, messageIconLeft } = this.data;
    let finalLeft = messageIconLeft;
    if (messageIconLeft > windowWidth / 2 - 50) {
      finalLeft = windowWidth - 100;
    } else {
      finalLeft = 0;
    }
    this.setData({ messageIconLeft: finalLeft });
  
    // 保存位置
    wx.setStorage({
      key: 'messageIconPosition',
      data: { left: finalLeft, top: this.data.messageIconTop }
    });
  },
  
  // 全屏遮罩的 touchmove 处理（空函数即可，catchtouchmove 会阻止页面滚动）
  onBlockerMove() {
    // 不需要做事，存在即拦截
  },
  
  toMessage() {
    // 如果刚刚发生拖动，就不触发跳转
    if (this.data.isMoved) {
      this.setData({ isMoved: false });
      return;
    }
    this.setData({ isMessageIconShaking: false });
    wx.navigateTo({ url: '/pages/message/message' });
  },
  
  initMessageIconPosition() {
    wx.getSystemInfo({
      success: (res) => {
        this.setData({
          windowWidth: res.windowWidth,
          windowHeight: res.windowHeight
        });
        wx.getStorage({
          key: 'messageIconPosition',
          success: (res) => {
            this.setData({
              messageIconLeft: res.data.left,
              messageIconTop: res.data.top
            });
          },
          fail: () => {
            // 默认位置：右侧中间 — 使用 left/top 而不是 right/bottom
            this.setData({
              messageIconLeft: res.windowWidth - 100,
              messageIconTop: res.windowHeight / 2 - 50
            });
          }
        });
      }
    });
  },
  
  // 初始化悬浮图标位置
  initMessageIconPosition() {
      // 获取窗口尺寸
      wx.getSystemInfo({
          success: (res) => {
              this.setData({
                  windowWidth: res.windowWidth,
                  windowHeight: res.windowHeight
              });
              
              // 尝试从本地存储获取保存的位置
              wx.getStorage({
                  key: 'messageIconPosition',
                  success: (res) => {
                      this.setData({
                          messageIconLeft: res.data.left,
                          messageIconTop: res.data.top
                      });
                  },
                  fail: () => {
                      // 默认位置：右侧中间
                      this.setData({
                          messageIconLeft: res.windowWidth - 100,
                          messageIconTop: res.windowHeight / 2 - 50
                      });
                  }
              });
          }
      });
  },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
      this.taggleLogin()
      this.getCount()
      this.getSoldCount()
      this.getUnreadCount()
      this.initMessageIconPosition()
   },

   /**
    * 生命周期函数--监听页面初次渲染完成
    */
   onReady() {

   },

   /**
    * 生命周期函数--监听页面显示
    */
   onShow() {
       this.taggleLogin()
       this.getCount()
       this.getSoldCount()
       this.getUnreadCount()
       
       // 检查是否需要刷新
       if (getApp().globalData.needRefresh) {
           this.getCount()
           this.getSoldCount()
           this.getUnreadCount()
           getApp().globalData.needRefresh = false
       }
   },

   /**
    * 生命周期函数--监听页面隐藏
    */
   onHide() {

   },

   /**
    * 生命周期函数--监听页面卸载
    */
   onUnload() {

   },

   /**
    * 页面相关事件处理函数--监听用户下拉动作
    */
   onPullDownRefresh() {
       this.onLoad()
       wx.stopPullDownRefresh();
   },

   /**
    * 页面上拉触底事件的处理函数
    */
   onReachBottom() {

   },

   /**
    * 用户点击右上角分享
    */
   onShareAppMessage() {

   }
})