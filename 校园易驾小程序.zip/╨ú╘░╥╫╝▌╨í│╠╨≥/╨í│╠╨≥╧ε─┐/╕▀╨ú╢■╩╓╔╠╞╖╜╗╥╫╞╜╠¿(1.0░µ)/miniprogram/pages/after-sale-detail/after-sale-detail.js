const db = wx.cloud.database()
Page({
    data: {
        afterSaleId: '',
        afterSaleDetail: null,
        loading: true
    },
    onLoad(options) {
        const { id } = options
        this.setData({ afterSaleId: id })
        this.loadAfterSaleDetail(id)
    },
    loadAfterSaleDetail(id) {
        db.collection('after_sales').doc(id).get().then(res => {
            this.setData({
                afterSaleDetail: res.data,
                loading: false
            })
        }).catch(err => {
            console.error('加载售后详情失败:', err)
            wx.showToast({
                title: '加载失败',
                icon: 'none'
            })
            this.setData({ loading: false })
        })
    },
    // 预览图片
    previewImage(e) {
        const src = e.currentTarget.dataset.src
        wx.previewImage({
            current: src,
            urls: this.data.afterSaleDetail.images
        })
    },
    // 联系客服
    contactCustomerService() {
        wx.showActionSheet({
            itemList: ['在线客服', '客服电话'],
            success: (res) => {
                if (res.tapIndex === 0) {
                    // 这里可以跳转到客服聊天页面
                    wx.showToast({
                        title: '跳转至客服聊天',
                        icon: 'none'
                    })
                } else if (res.tapIndex === 1) {
                    wx.makePhoneCall({
                        phoneNumber: '400-123-4567'
                    })
                }
            }
        })
    }
})