const db = wx.cloud.database()
Page({

    /**
     * 页面的初始数据
     */
    data: {
        userData: {},
        disable: true,
        showform: false
    },
    outlogin() {
        wx.removeStorageSync('userId')
        wx.removeStorageSync('id')
        wx.removeStorageSync('avator')
        wx.removeStorageSync('uname')
        wx.setStorageSync('islogin', false)
        wx.showToast({
            title: '退出成功!',
            icon: "success"
        })
        setTimeout(() => {
            wx.switchTab({
                url: '/pages/center/center',
            })
        }, 500)
    },
    // 更新头像/上传头像
    upAvator() {
        wx.chooseImage({
            count: 1,
            sizeType: ['original', 'compressed'],
            sourceType: ['album', 'camera'],
            success: async (res) => {
                const tempFilePaths = res.tempFilePaths[0];
                const id = wx.getStorageSync('id');
                // console.log(id);
                // 删除旧的头像
                const avator = wx.getStorageSync('avator')
                // 如果为空，就不让上传
                if (avator) {
                    // console.log("旧头像", avator)
                    // 定义删除函数
                    function deleteImageByFileId(fileId) {
                        // console.log(fileId)
                        return new Promise((resolve, reject) => {
                            // console.log("你好呀", fileId)
                            wx.cloud.deleteFile({
                                fileList: [fileId],
                            }).then(res => {
                                resolve(res);
                            }).catch(err => {
                                reject(err);
                            });
                        });
                    }
                    // 调用删除函数
                    deleteImageByFileId(avator).then(() => {
                        console.log('旧头像删除成功');
                    }).catch(err => {
                        console.error('旧头像删除失败：', err);
                        return;
                    });
                } else {
                    return;
                }

                try {
                    // 上传头像到云存储
                    const cloudRes = await wx.cloud.uploadFile({
                        cloudPath: `avatars/${Date.now()}-${Math.random()}.jpg`, // 自定义云存储中的文件名
                        filePath: tempFilePaths
                    });
                    // 更新数据库中的用户信息，存储云存储文件 ID
                    await db.collection('users').doc(id).update({
                        data: {
                            avator: cloudRes.fileID
                        }
                    });
                    // 更新数据库中的用户发布的商品信息，存储云存储文件ID
                    await db.collection('goods').where({
                        id: id
                    }).update({
                        data: {
                            avatorImg: cloudRes.fileID
                        }
                    })
                    // console.log(updateRes);
                    wx.showToast({
                        title: '头像更新成功!',
                    });
                    this.getuserData()

                } catch (error) {
                    console.error(error);
                    wx.showToast({
                        title: '头像更新失败!',
                        icon: 'none'
                    });
                }
                console.log(tempFilePaths);
            },
            fail: (error) => {
                console.error('选择图片失败：', error);
            }
        });
    },
    // 获取用户的信息
    getuserData() {
        const id = wx.getStorageSync('id')
        db.collection("users").doc(id).get().then(res => {
            this.setData({
                userData: res.data
            })
            wx.setStorageSync('avator', res.data.avator)
            wx.setStorageSync('uname', res.data.uname)
            wx.setStorageSync('tel', res.data.tel)
        })
    },
    // 显示表单
    showForm() {
        this.setData({
            showform: true
        })
    },
    concelForm() {
        this.setData({
            showform: false
        })
    },
    updateUser(e) {
        const { uname, signature, tel } = e.detail.value
        const id = wx.getStorageSync('id')
        db.collection("users").doc(id).get().then(res => {
            if (uname === '') {
                wx.showToast({
                    title: '昵称不能为空!',
                    icon: "error"
                })
                return;
            }
            if (signature === "") {
                wx.showToast({
                    title: '个签不为空!',
                    icon: "error"
                })
                return;
            }
            if (tel === "") {
                wx.showToast({
                    title: '电话不为空!',
                    icon: "error"
                })
                return;
            }


            if (res.data.uname === uname && res.data.signature === signature && res.data.tel === tel) {
                wx.showToast({
                    title: '修改后再提交!',
                    icon: "error"
                })
                return;
            } else {
                db.collection("users").doc(id).update({
                    data: {
                        uname,
                        signature,
                        tel
                    }
                }).then(res => {
                    // console.log(res)
                    wx.showToast({
                        title: '修改成功!',
                        icon: "success"
                    })
                    this.getuserData()
                    this.setData({
                        showform: false
                    })
                })
            }
        })
    },



    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
        this.getuserData()
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {
        // this.getuserData()
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})