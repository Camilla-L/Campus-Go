const db = wx.cloud.database()
Page({
    /**
     * 页面的初始数据
     */
    data: {
        id: Number,
        goodsData: null,
        isFavorite: false,
        buyerInfo: null
    },

    // 获取商品的详细信息
    getGoodsDetail() {
        db.collection("goods").doc(this.data.id).get().then(res => {
            this.setData({
                goodsData: res.data
            })
        })
    },

    // 格式化时间
    formatTime: function(dateString) {
        if (!dateString) return '';
        
        const date = new Date(dateString);
        const now = new Date();
        const diff = now - date;
        const minutes = Math.floor(diff / (1000 * 60));
        const hours = Math.floor(diff / (1000 * 60 * 60));
        const days = Math.floor(diff / (1000 * 60 * 60 * 24));
        
        if (minutes < 1) {
            return '刚刚';
        } else if (minutes < 60) {
            return `${minutes}分钟前`;
        } else if (hours < 24) {
            return `${hours}小时前`;
        } else if (days < 7) {
            return `${days}天前`;
        } else {
            return `${date.getMonth() + 1}月${date.getDate()}日`;
        }
    },

    // 联系卖家
    contactSeller: function() {
        if (this.data.goodsData && this.data.goodsData.contact) {
            wx.makePhoneCall({
                phoneNumber: this.data.goodsData.contact
            });
        }
    },

    // 切换收藏状态
    toggleFavorite: function() {
        const goodsId = this.data.id;
        let favorites = wx.getStorageSync('favorites') || [];
        
        if (this.data.isFavorite) {
            // 取消收藏
            favorites = favorites.filter(id => id !== goodsId);
            wx.showToast({
                title: '已取消收藏',
                icon: 'success'
            });
        } else {
            // 添加收藏
            favorites.push(goodsId);
            wx.showToast({
                title: '已添加收藏',
                icon: 'success'
            });
        }
        
        wx.setStorageSync('favorites', favorites);
        this.setData({
            isFavorite: !this.data.isFavorite
        });
    },

    // 分享商品
    shareGoods: function() {
        wx.showShareMenu({
            withShareTicket: true
        });
    },

    // 立即购买
async buyNow() {
  if (!this.data.goodsData) return;
  
  // 检查是否已登录
  const userId = wx.getStorageSync('id');
  if (!userId) {
      wx.showToast({
          title: '请先登录',
          icon: 'none'
      });
      setTimeout(() => {
          wx.switchTab({
              url: '/pages/center/center',
          })
      }, 1000);
      return;
  }
  
  // 跳转到地址页面
  wx.navigateTo({
    url: `/pages/address/address?goodsId=${this.data.id}`
  });
},

// 确认购买 (从地址页面回调后执行)
async confirmPurchase() {
  if (!this.data.buyerInfo) return;
  
  wx.showModal({
    title: '确认购买',
    content: `确定要购买「${this.data.goodsData.title}」吗？`,
    success: async (res) => {
      if (res.confirm) {
        wx.showLoading({
          title: '处理中...'
        });
        
        try {
          const userId = wx.getStorageSync('id');
          
          // 创建订单
          const orderData = {
            goodsId: this.data.id,
            goodsData: this.data.goodsData,
            buyerId: userId,
            buyerName: this.data.buyerInfo.name,
            buyerPhone: this.data.buyerInfo.phone,
            buyerAddress: `${this.data.buyerInfo.area} ${this.data.buyerInfo.detailAddress}`,
            preferredTime: this.data.buyerInfo.preferredTime,
            notes: this.data.buyerInfo.notes,
            sellerId: this.data.goodsData.userId,
            sellerName: this.data.goodsData.seller.name,
            sellerPhone: this.data.goodsData.contact,
            price: this.data.goodsData.price,
            status: 'pending',
            createTime: db.serverDate(),
            orderNumber: 'DD' + Date.now() + Math.floor(Math.random() * 1000)
          };
          
          // 添加到订单集合
          const orderRes = await db.collection('orders').add({
            data: orderData
          });
          
          // 添加到买家的购买记录
          await db.collection('user_orders').add({
            data: {
              userId: userId,
              orderId: orderRes._id,
              goodsId: this.data.id,
              type: 'bought',
              status: 'pending',
              createTime: db.serverDate(),
              orderNumber: orderData.orderNumber
            }
          });
          
          // 添加到卖家的售出记录
          await db.collection('user_orders').add({
            data: {
              userId: this.data.goodsData.userId,
              orderId: orderRes._id,
              goodsId: this.data.id,
              type: 'sold',
              status: 'pending',
              createTime: db.serverDate(),
              orderNumber: orderData.orderNumber,
              buyerId: userId,
              buyerName: wx.getStorageSync('uname')
            }
          });
          
          // 更新商品状态为交易中
          await db.collection('goods').doc(this.data.id).update({
            data: {
              saleStatus: 'trading'
            }
          });
          
          wx.hideLoading();
          wx.showModal({
            title: '购买成功',
            content: '已生成订单，卖家会尽快联系您',
            showCancel: false,
            success: () => {
              // 返回上一页
              wx.navigateBack();
            }
          });
        } catch (error) {
          console.error('购买失败:', error);
          wx.hideLoading();
          wx.showToast({
            title: '购买失败，请重试',
            icon: 'none'
          });
        }
      }
    }
  });
},

// 获取买家信息
getBuyerInfo() {
  return new Promise((resolve) => {
    wx.showModal({
      title: '填写收货信息',
      content: '请提供您的联系方式、地址和希望的配送时间',
      editable: true,
      placeholderText: '格式: 电话,地址,配送时间\n例如: 13800138000,广州市大学城,周末配送',
      success: (res) => {
        if (res.confirm) {
          const info = res.content.split(',');
          if (info.length >= 3) {
            resolve({
              phone: info[0].trim(),
              address: info[1].trim(),
              preferredTime: info[2].trim()
            });
          } else {
            wx.showToast({
              title: '信息格式不正确',
              icon: 'none'
            });
            resolve(null);
          }
        } else {
          resolve(null);
        }
      }
    });
  });
},

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
        const { id } = options
        this.setData({
            id
        })
        
        // 检查是否已收藏
        const favorites = wx.getStorageSync('favorites') || [];
        this.setData({
            isFavorite: favorites.includes(id)
        });
        
        this.getGoodsDetail()
    },

    onShareAppMessage: function() {
        return {
            title: this.data.goodsData ? this.data.goodsData.title : '校园易驾电瓶车',
            path: `/pages/detail/detail?id=${this.data.id}`
        };
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    }
})