Component({
  properties: {
    post: {
      type: Object,
      value: {},
      observer: function(newVal) {
        if (newVal && newVal.comments) {
          // 计算热门评论
          this.calculateHotComment(newVal.comments);
        }
      }
    }
  },

  data: {
    isCommenting: false,
    commentContent: '',
    replyingTo: null,
    hotComment: null,   // 热门评论
    showAllComments: false, // 是否展示所有评论
    commentsCount: 0    // 评论总数
  },

  methods: {
    // 计算热门评论
    calculateHotComment(comments) {
      if (comments.length === 0) {
        this.setData({
          hotComment: null,
          commentsCount: 0
        });
        return;
      }

      // 按点赞数降序排序，如果点赞数相同，按时间降序
      const sortedComments = [...comments].sort((a, b) => {
        if (b.likeCount !== a.likeCount) {
          return (b.likeCount || 0) - (a.likeCount || 0);
        }
        return new Date(b.createTime) - new Date(a.createTime);
      });

      this.setData({
        hotComment: sortedComments[0],
        commentsCount: comments.length
      });
    },

    // 展开/收起全部评论
    toggleAllComments() {
      this.setData({
        showAllComments: !this.data.showAllComments
      });
    },
    // 点赞/取消点赞
    onLike(e) {
      const post = e.currentTarget.dataset.post;
      this.triggerEvent('like', { postId: post._id });
    },

    // 评论
    onComment(e) {
      const post = e.currentTarget.dataset.post;
      this.setData({
        isCommenting: true,
        replyingTo: null
      });
    },

    // 分享
    onShare(e) {
      const post = e.currentTarget.dataset.post;
      this.triggerEvent('share', { post });
    },

    // 更多操作
    onMoreActions(e) {
      const post = e.currentTarget.dataset.post;
      this.triggerEvent('more', { post });
    },

    // 评论输入
    onCommentInput(e) {
      this.setData({
        commentContent: e.detail.value
      });
    },

    // 发送评论
    onSendComment() {
      if (!this.data.commentContent.trim()) return;
      
      this.triggerEvent('comment', {
        postId: this.data.post._id,
        content: this.data.commentContent,
        replyTo: this.data.replyingTo
      });

      this.setData({
        isCommenting: false,
        commentContent: '',
        replyingTo: null
      });
    },

    // 回复评论
    onReplyComment(e) {
      const comment = e.detail.comment;
      this.setData({
        isCommenting: true,
        replyingTo: comment.author.name,
        commentContent: `@${comment.author.name} `
      });
    },

    // 查看所有评论
    onViewAllComments(e) {
      const post = e.currentTarget.dataset.post;
      this.triggerEvent('viewcomments', { post });
    },

    // 预览图片
    previewImage(e) {
      const url = e.currentTarget.dataset.url;
      const urls = e.currentTarget.dataset.urls;
      wx.previewImage({
        current: url,
        urls: urls
      });
    }
  }
});