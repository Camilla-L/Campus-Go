Component({
  properties: {
    name: {
      type: String,
      value: "",
    },
    toolParams: {
      type: Object,
      value: {},
    },
    toolData: {
      type: Object,
      value: {},
    },
  },
  data: {},
  lifetimes: {},
});
