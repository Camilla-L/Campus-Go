// app.js
App({
  onLaunch: function () {
    if (!wx.cloud) {
      console.error('请使用 2.2.3 或以上的基础库以使用云能力');
    } else {
      wx.cloud.init({
        env: 'cloud1-4ghjbgor0a9e5c2a',
        traceUser: true,
      });
    }

    this.globalData = {};
  },
  globalData: {
    needRefresh: false // 添加全局变量，用于标记是否需要刷新
  },
});
