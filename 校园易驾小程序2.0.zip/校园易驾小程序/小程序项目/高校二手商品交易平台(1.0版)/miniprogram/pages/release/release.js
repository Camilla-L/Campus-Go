const db = wx.cloud.database()

Page({
    /**
     * 页面的初始数据
     */
    data: {
        categoryList: [
            { id: 1, className: "收车" },
            { id: 2, className: "卖车" },
            { id: 3, className: "租车" },
            { id: 4, className: "出租" },
            { id: 5, className: "质检" },
            { id: 6, className: "维修" },
            
        ],
        newdegreeList: [
            { id: 1, newdegreeName: "全新" },
            { id: 2, newdegreeName: "99新" },
            { id: 3, newdegreeName: "95新" },
            { id: 4, newdegreeName: "9成新" },
            { id: 5, newdegreeName: "8成新" },
            { id: 6, newdegreeName: "无" },
        ],
        brandList: [
          "九号", "雅迪", "小牛", "爱玛", "台铃", 
          "新日", "绿源", "小鸟", "其他品牌"
      ],
      conditionList: [
          { id: 1, name: "优秀", value: "excellent" },
          { id: 2, name: "良好", value: "good" },
          { id: 3, name: "一般", value: "fair" }
      ],
      // 标签选项
      tagOptions: [
          "官方认证", "有保险", "支持试骑", "急出", "可小刀", 
          "包邮", "送配件", "电池新换", "无划痕", "无维修史"
      ],
      showDropdown: false,
      selectedCategory: null,
      shownewdegree: false,
      selectednewdegree: null,
      showBrand: false,
      selectedBrand: null,
      showCondition: false,
      selectedCondition: null,
      showTags: false,
      selectedTags: [],
      title: '',
      description: '',
      price: '0.00',
      originalPrice: '0.00',
      range: '',
      age: '',
      location: '广州大学城',
      tel: '',
      uploadedImagePaths: [],
      Currenttime: '',
      isUploading: false,
      uploadProgress: 0
  },

  // 处理图片上传 - 优化版
  async uploadImage() {
      if (this.data.uploadedImagePaths.length >= 9) {
          wx.showToast({
              title: '最多上传9张图片',
              icon: 'none'
          });
          return;
      }
      
      try {
          this.setData({ isUploading: true, uploadProgress: 0 });
          
          const res = await wx.chooseImage({
              count: 9 - this.data.uploadedImagePaths.length,
              sizeType: ['compressed'], // 只使用压缩模式
              sourceType: ['album', 'camera'],
          });
          
          // 显示上传进度
          const totalFiles = res.tempFilePaths.length;
          let uploadedCount = 0;
          
          const uploadTasks = res.tempFilePaths.map((filePath, index) => {
              return new Promise((resolve, reject) => {
                  const uploadTask = wx.cloud.uploadFile({
                      cloudPath: `goods_images/${Date.now()}-${Math.random().toString(36).substr(2, 9)}.jpg`,
                      filePath: filePath,
                      success: resolve,
                      fail: reject
                  });
                  
                  // 监听上传进度
                  uploadTask.onProgressUpdate((res) => {
                      if (res.progress === 100) {
                          uploadedCount++;
                          const progress = Math.round((uploadedCount / totalFiles) * 100);
                          this.setData({ uploadProgress: progress });
                      }
                  });
              });
          });
          
          const results = await Promise.all(uploadTasks);
          
          this.setData({
              uploadedImagePaths: [...this.data.uploadedImagePaths, ...results.map(item => item.fileID)],
              isUploading: false,
              uploadProgress: 0
          });
          
          wx.showToast({
              title: `上传成功${results.length}张图片`,
              icon: 'success'
          });
      } catch (error) {
          console.error('上传失败:', error);
          this.setData({ isUploading: false, uploadProgress: 0 });
          
          wx.showToast({
              title: '上传失败，请重试',
              icon: 'none'
          });
      }
  },

  // 预览图片
  previewImage(e) {
      const index = e.currentTarget.dataset.index;
      wx.previewImage({
          current: this.data.uploadedImagePaths[index],
          urls: this.data.uploadedImagePaths
      });
  },

  deleteImage(e) {
      const index = e.currentTarget.dataset.index;
      wx.showModal({
          title: '确认删除',
          content: '确定要删除这张图片吗？',
          success: (res) => {
              if (res.confirm) {
                  const newImagePaths = [...this.data.uploadedImagePaths];
                  newImagePaths.splice(index, 1);
                  this.setData({
                      uploadedImagePaths: newImagePaths
                  });
              }
          }
      });
  },

  // 将获取过来的数据的time转换成常用的时间格式
  ParseDate() {
      const currentDate = new Date();
      const formatted = currentDate.toString();
      const date = formatted.slice(8, 10)
      const year = formatted.slice(11, 15)
      const hour = formatted.slice(16, 24)
      const month = formatted.slice(4, 7)
      const monthsArr = {
          Jan: '01', Feb: '02', Mar: '03', Apr: '04', May: '05', Jun: '06',
          Jul: '07', Aug: '08', Sep: '09', Oct: '10', Nov: '11', Dec: '12'
      };
      this.setData({
          Currenttime: `${year}.${monthsArr[month]}.${date}  ${hour}`
      })
  },

  // 处理商品信息提交
  async addData(e) {
      const formData = e.detail.value;
      const currentDate = new Date();
      const id = wx.getStorageSync('id');
      const avator = wx.getStorageSync('avator');
      const uname = wx.getStorageSync('uname');
      this.ParseDate();

      // 检查各项是否为空
      if (!formData.title || !formData.description || !formData.price || 
          !this.data.selectedCategory || !this.data.selectednewdegree || 
          !formData.tel || !formData.range || !formData.age || 
          !this.data.selectedBrand || !this.data.selectedCondition) {
          wx.showToast({
              title: '请填写所有必填项',
              icon: 'none'
          });
          return;
      }

      // 处理价格
      let price = parseFloat(formData.price) || 0;
      let originalPrice = parseFloat(formData.originalPrice) || price * 1.5;
      
      // 生成符合目标格式的商品数据
      const goodsInfo = {
          title: formData.title,
          description: formData.description,
          price: price.toFixed(2),
          originalPrice: originalPrice.toFixed(2),
          brand: this.data.selectedBrand,
          range: parseInt(formData.range) || 0,
          age: parseInt(formData.age) || 0,
          tags: this.data.selectedTags, // 添加标签
          location: this.data.location,
          postTime: currentDate.toISOString(),
          images: this.data.uploadedImagePaths || [],
          condition: this.data.selectedCondition,
          seller: {
              name: uname,
              avatar: avator,
              rating: 4.5, // 默认评分
              sales: 0     // 初始销量为0
          },
          contact: formData.tel,
          category: this.data.selectedCategory,
          newdegree: this.data.selectednewdegree,
          hit: 0,
          showtime: this.data.Currenttime,
          userId: id, // 使用userId字段
          sellerId: id, // 添加卖家ID字段
          status: 'on_sale', // 商品状态：出售中
          saleStatus: 'available' // 销售状态：可购买
      };

      try {
          wx.showLoading({
              title: '发布中...',
          });
          
          // 添加商品到数据库
          const result = await db.collection('goods').add({
              data: goodsInfo,
          });
          
          // 同时添加到用户的发布记录中
          await db.collection('user_goods').add({
              data: {
                  userId: id,
                  goodsId: result._id,
                  type: 'published',
                  status: 'on_sale',
                  createTime: db.serverDate()
              }
          });
          
          wx.hideLoading();
          wx.showToast({
              title: '商品发布成功',
              icon: 'success',
              duration: 2000,
              success: () => {
                  setTimeout(() => {
                      wx.navigateBack();
                  }, 2000);
              }
          });
          
      } catch (error) {
          console.error('提交失败:', error);
          wx.hideLoading();
          wx.showToast({
              title: '提交失败，请重试',
              icon: 'none'
          });
      }
  },

  // 处理分类下拉菜单的切换
  toggleDropdown() {
      this.setData({
          showDropdown: !this.data.showDropdown,
          shownewdegree: false,
          showBrand: false,
          showCondition: false,
          showTags: false
      });
  },

  selectClass(e) {
      const category = e.currentTarget.dataset.param;
      this.setData({
          selectedCategory: category,
          showDropdown: false,
      });
  },

  // 处理新旧程度下拉菜单的切换
  togglenewdegree() {
      this.setData({
          shownewdegree: !this.data.shownewdegree,
          showDropdown: false,
          showBrand: false,
          showCondition: false,
          showTags: false
      });
  },

  selectnewdegree(e) {
      const newdegree = e.currentTarget.dataset.params;
      this.setData({
          selectednewdegree: newdegree,
          shownewdegree: false,
      });
  },

  // 处理品牌下拉菜单
  toggleBrand() {
      this.setData({
          showBrand: !this.data.showBrand,
          showDropdown: false,
          shownewdegree: false,
          showCondition: false,
          showTags: false
      });
  },

  selectBrand(e) {
      const brand = e.currentTarget.dataset.brand;
      this.setData({
          selectedBrand: brand,
          showBrand: false,
      });
  },

  // 处理车况下拉菜单
  toggleCondition() {
      this.setData({
          showCondition: !this.data.showCondition,
          showDropdown: false,
          shownewdegree: false,
          showBrand: false,
          showTags: false
      });
  },

  selectCondition(e) {
      const condition = e.currentTarget.dataset.condition;
      this.setData({
          selectedCondition: condition,
          showCondition: false,
      });
  },

  // 处理标签选择
  toggleTags() {
      this.setData({
          showTags: !this.data.showTags,
          showDropdown: false,
          shownewdegree: false,
          showBrand: false,
          showCondition: false
      });
  },

  toggleTag(e) {
      const tag = e.currentTarget.dataset.tag;
      let selectedTags = [...this.data.selectedTags];
      
      if (selectedTags.includes(tag)) {
          selectedTags = selectedTags.filter(t => t !== tag);
      } else {
          if (selectedTags.length >= 5) {
              wx.showToast({
                  title: '最多选择5个标签',
                  icon: 'none'
              });
              return;
          }
          selectedTags.push(tag);
      }
      
      this.setData({ selectedTags });
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
      const telphone = wx.getStorageSync('tel')
      this.setData({
          tel: telphone
      })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
      const telphone = wx.getStorageSync('tel')
      const id = wx.getStorageSync('id')
      this.setData({
          tel: telphone
      })
      if (!id) {
          wx.showToast({
              title: '请先登录!',
              icon: 'none'
          })
          setTimeout(() => {
              wx.switchTab({
                  url: '/pages/center/center',
              })
          }, 1000)
      }
  },
})