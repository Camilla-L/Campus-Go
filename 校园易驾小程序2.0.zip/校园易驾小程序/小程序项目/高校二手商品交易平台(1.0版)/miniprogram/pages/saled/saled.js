const db = wx.cloud.database()
Page({

    /**
     * 页面的初始数据
     */
    data: {
        orderList: [],
        isLoading: true,
        isShow: false,
        contents: "暂无订单数据",
        selectedTab: 'all', // 全部订单
        tabs: [
            { key: 'all', name: '全部订单' },
            { key: 'pending', name: '待处理' },
            { key: 'shipped', name: '已发货' },
            { key: 'completed', name: '已完成' }
        ]
    },

    // 切换订单状态标签
    switchTab(e) {
        const tab = e.currentTarget.dataset.tab;
        this.setData({
            selectedTab: tab,
            isLoading: true
        });
        this.getOrders(tab);
    },

    // 获取订单数据
    getOrders(status = 'all') {
        const sellerId = wx.getStorageSync('id');
        if (!sellerId) {
            this.setData({
                isLoading: false,
                isShow: true,
                contents: "请先登录"
            });
            return;
        }

        let query = { sellerId: sellerId };
        
        // 根据状态筛选
        if (status !== 'all') {
            query.status = status;
        }

        db.collection("orders")
            .where(query)
            .orderBy('createTime', 'desc')
            .get()
            .then(res => {
                if (res.data.length === 0) {
                    this.setData({
                        isShow: true,
                        contents: "暂无订单数据",
                        orderList: [],
                        isLoading: false
                    });
                } else {
                    this.setData({
                        orderList: res.data,
                        isShow: false,
                        isLoading: false
                    });
                }
            })
            .catch(err => {
                console.error("获取订单失败", err);
                this.setData({
                    isLoading: false,
                    isShow: true,
                    contents: "获取订单失败，请重试"
                });
                wx.showToast({
                    title: '获取订单失败',
                    icon: 'none'
                });
            });
    },

    // 查看订单详情
    viewOrderDetail(e) {
        const orderId = e.currentTarget.dataset.id;
        wx.navigateTo({
            url: `/pages/orderDetail/orderDetail?id=${orderId}&role=seller`
        });
    },

    // 联系买家
    contactBuyer(e) {
        const phone = e.currentTarget.dataset.phone;
        if (phone) {
            wx.makePhoneCall({
                phoneNumber: phone
            });
        } else {
            wx.showToast({
                title: '买家未提供联系方式',
                icon: 'none'
            });
        }
    },

    // 发送消息给买家
    messageBuyer(e) {
        const buyerId = e.currentTarget.dataset.buyerid;
        const buyerName = e.currentTarget.dataset.buyername;
        
        wx.showModal({
            title: '联系买家',
            content: `确定要联系买家「${buyerName}」吗？`,
            success: (res) => {
                if (res.confirm) {
                    // 这里可以集成即时通讯功能
                    // 暂时使用复制微信号的方式
                    wx.setClipboardData({
                        data: `买家ID: ${buyerId}`,
                        success: () => {
                            wx.showToast({
                                title: '买家ID已复制，请使用其他方式联系',
                                icon: 'success'
                            });
                        }
                    });
                }
            }
        });
    },

    // 更新订单状态
    updateOrderStatus(e) {
        const { id, status } = e.currentTarget.dataset;
        const statusText = {
            'pending': '确认发货',
            'shipped': '确认收货',
            'completed': '已完成'
        }[status] || '处理';

        wx.showModal({
            title: '确认操作',
            content: `确定要${statusText}吗？`,
            success: async (res) => {
                if (res.confirm) {
                    wx.showLoading({
                        title: '处理中...',
                    });

                    try {
                        let updateData = {};
                        
                        // 根据当前状态确定下一步状态
                        if (status === 'pending') {
                            updateData.status = 'shipped';
                            updateData.shipTime = new Date().toISOString();
                        } else if (status === 'shipped') {
                            updateData.status = 'completed';
                            updateData.completeTime = new Date().toISOString();
                            
                            // 订单完成时，将商品状态改为已售出
                            const orderRes = await db.collection("orders").doc(id).get();
                            if (orderRes.data && orderRes.data.goodsId) {
                                await db.collection("goods").doc(orderRes.data.goodsId).update({
                                    data: {
                                        saleStatus: 'sold'
                                    }
                                });
                            }
                        }

                        await db.collection("orders").doc(id).update({
                            data: updateData
                        });

                        wx.hideLoading();
                        wx.showToast({
                            title: '操作成功',
                            icon: 'success'
                        });

                        // 刷新订单列表
                        this.getOrders(this.data.selectedTab);
                    } catch (error) {
                        console.error('更新订单状态失败:', error);
                        wx.hideLoading();
                        wx.showToast({
                            title: '操作失败，请重试',
                            icon: 'none'
                        });
                    }
                }
            }
        });
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
        this.getOrders();
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {
        // 页面显示时刷新数据
        this.getOrders(this.data.selectedTab);
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {
        this.getOrders(this.data.selectedTab);
        wx.stopPullDownRefresh();
    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})