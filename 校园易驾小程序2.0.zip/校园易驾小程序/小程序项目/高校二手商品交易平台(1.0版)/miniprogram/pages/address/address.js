const db = wx.cloud.database();

Page({
  data: {
    goodsId: null,
    formData: {
      name: '',
      phone: '',
      area: '',
      detailAddress: '',
      preferredTime: '任意时间',
      notes: ''
    },
    timeOptions: [
      '工作日白天 (9:00-18:00)',
      '工作日晚上 (18:00-22:00)',
      '周末白天 (9:00-18:00)',
      '周末晚上 (18:00-22:00)',
      '任意时间'
    ],
    showTimePicker: false,
    isRecognizing: false,
    region: ['广东省', '广州市', '番禺区']
  },

  onLoad: function(options) {
    this.setData({
      goodsId: options.goodsId
    });
    this.getSavedAddress();
  },

  getSavedAddress: function() {
    const savedAddress = wx.getStorageSync('userAddress');
    if (savedAddress) {
      this.setData({
        formData: savedAddress,
        region: savedAddress.area ? savedAddress.area.split(' ') : ['广东省', '广州市', '番禺区']
      });
    }
  },

  onInputChange: function(e) {
    const field = e.currentTarget.dataset.field;
    this.setData({
      ['formData.' + field]: e.detail.value
    });
  },

  bindRegionChange: function(e) {
    this.setData({
      region: e.detail.value,
      'formData.area': e.detail.value.join(' ')
    });
  },

  toggleTimePicker: function() {
    this.setData({
      showTimePicker: !this.data.showTimePicker
    });
  },

  selectTime: function(e) {
    const time = e.currentTarget.dataset.time;
    this.setData({
      'formData.preferredTime': time,
      showTimePicker: false
    });
  },

  useWechatAddress: function() {
    const that = this;
    wx.chooseAddress({
      success: function(res) {
        const area = res.provinceName + ' ' + res.cityName + ' ' + res.countyName;
        that.setData({
          'formData.name': res.userName,
          'formData.phone': res.telNumber,
          'formData.area': area,
          'formData.detailAddress': res.detailInfo,
          region: [res.provinceName, res.cityName, res.countyName]
        });
      },
      fail: function(err) {
        console.error("获取微信地址失败", err);
        if (err.errMsg === 'chooseAddress:fail auth deny') {
          wx.showModal({
            title: '提示',
            content: '您拒绝了地址授权，请在设置中打开地址权限',
            showCancel: false
          });
        }
      }
    });
  },

  recognizeFromClipboard: function() {
    const that = this;
    that.setData({ isRecognizing: true });
    
    wx.getClipboardData({
      success: function(res) {
        const data = res.data;
        if (!data) {
          wx.showToast({
            title: '剪贴板为空',
            icon: 'none'
          });
          return;
        }
        
        const recognizedInfo = that.parseAddressText(data);
        
        if (recognizedInfo) {
          that.setData({
            'formData.name': recognizedInfo.name || that.data.formData.name,
            'formData.phone': recognizedInfo.phone || that.data.formData.phone,
            'formData.area': recognizedInfo.area || that.data.formData.area,
            'formData.detailAddress': recognizedInfo.detailAddress || that.data.formData.detailAddress
          });
          
          if (recognizedInfo.area) {
            that.setData({
              region: recognizedInfo.area.split(' ')
            });
          }
          
          wx.showToast({
            title: '地址信息已识别',
            icon: 'success'
          });
        } else {
          wx.showToast({
            title: '未识别到地址信息',
            icon: 'none'
          });
        }
      },
      complete: function() {
        that.setData({ isRecognizing: false });
      }
    });
  },

  parseAddressText: function(text) {
    const result = {};
    
    // 匹配手机号
    const phoneMatch = text.match(/1[3-9]\d{9}/);
    if (phoneMatch) {
      result.phone = phoneMatch[0];
    }
    
    // 匹配姓名 (简单逻辑)
    const nameMatch = text.match(/[\u4e00-\u9fa5]{2,4}/);
    if (nameMatch && !text.includes('省') && !text.includes('市') && !text.includes('区')) {
      result.name = nameMatch[0];
    }
    
    // 匹配地址
    const addressMatch = text.match(/([\u4e00-\u9fa5]{2,7}省)?([\u4e00-\u9fa5]{2,7}市)?([\u4e00-\u9fa5]{2,7}区)?([\u4e00-\u9fa5]{2,7}县)?(.+)/);
    if (addressMatch) {
      const province = addressMatch[1] || '';
      const city = addressMatch[2] || '';
      const district = addressMatch[3] || addressMatch[4] || '';
      const detail = addressMatch[5] || '';
      
      if (province || city || district) {
        result.area = (province + ' ' + city + ' ' + district).trim();
      }
      
      if (detail && detail.length > 5) {
        result.detailAddress = detail;
      }
    }
    
    return Object.keys(result).length > 0 ? result : null;
  },

  recognizeFromImage: function() {
    wx.showModal({
      title: '提示',
      content: '图片识别功能需要后端支持，目前暂未开放',
      showCancel: false
    });
  },

  validateForm: function() {
    const formData = this.data.formData;
    
    if (!formData.name) {
      wx.showToast({ title: '请输入收货人姓名', icon: 'none' });
      return false;
    }
    
    if (!formData.phone) {
      wx.showToast({ title: '请输入联系电话', icon: 'none' });
      return false;
    }
    
    if (!/^1[3-9]\d{9}$/.test(formData.phone)) {
      wx.showToast({ title: '请输入正确的手机号码', icon: 'none' });
      return false;
    }
    
    if (!formData.area) {
      wx.showToast({ title: '请选择省市区', icon: 'none' });
      return false;
    }
    
    if (!formData.detailAddress) {
      wx.showToast({ title: '请输入详细地址', icon: 'none' });
      return false;
    }
    
    return true;
  },

  saveAddress: function() {
    wx.setStorageSync('userAddress', this.data.formData);
  },

  submitForm: function() {
    if (!this.validateForm()) return;
    
    this.saveAddress();
    
    const pages = getCurrentPages();
    const prevPage = pages[pages.length - 2];
    
    if (prevPage && prevPage.route === 'pages/detail/detail') {
      wx.navigateBack({
        success: function() {
          if (prevPage.setData) {
            prevPage.setData({
              buyerInfo: this.data.formData
            });
          }
          
          if (prevPage.confirmPurchase) {
            setTimeout(function() {
              prevPage.confirmPurchase();
            }, 300);
          }
        }.bind(this)
      });
    } else {
      wx.navigateBack();
    }
  },

  cancel: function() {
    wx.navigateBack();
  }
});