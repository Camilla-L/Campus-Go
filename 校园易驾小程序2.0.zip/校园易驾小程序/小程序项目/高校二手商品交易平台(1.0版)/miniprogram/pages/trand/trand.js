// 连接云数据库
const db = wx.cloud.database()
const _ = db.command
Page({

    /**
     * 页面的初始数据
     */
    data: {
        classup: true,
        classdown: false,
        newGoodsList: [],
        downGoodsList: [],
        goods_id: "",
        isShow: Boolean,
        contents: "",
        startX: 0, // 滑动开始X坐标
        currentIndex: null // 当前滑动的项目索引
    },
    toup() {
        this.setData({
            classup: true,
            classdown: false
        })
        this.getData()


    },
    todown() {
        this.setData({
            classup: false,
            classdown: true
        })
        this.getDownGoods()
    },

    // 获取在卖商品数据
    getData() {
        const id = wx.getStorageSync('id')
        db.collection("goods").where({
            userId: id // 使用userId而不是id字段
        }).orderBy('postTime', 'desc').get().then(res => {
            if (res.data.length === 0) {
                this.setData({
                    isShow: true,
                    contents: "暂未发布的商品,快去发布吧...~"
                })
            } else {
                this.setData({
                    isShow: false,
                    contents: ""
                })
            }
            this.setData({
                newGoodsList: res.data
            })

        }).catch(err => {
            console.error("获取商品数据失败", err)
            wx.showToast({
                title: '获取数据失败',
                icon: 'none'
            })
        })
    },
    // 获取已下架商品数据
    getDownGoods() {
        const id = wx.getStorageSync('id')
        db.collection("downs").where({
            userId: id // 使用userId而不是id字段
        }).orderBy('downTime', 'desc').get().then(res => {
            if (res.data.length === 0) {
                this.setData({
                    isShow: true,
                    contents: "暂未下架过商品...~"
                })
            } else {
                this.setData({
                    isShow: false,
                    contents: ""
                })
            }
            this.setData({
                downGoodsList: res.data
            })

        }).catch(err => {
            console.error("获取下架商品数据失败", err)
            wx.showToast({
                title: '获取数据失败',
                icon: 'none'
            })
        })
    },
    // 下架商品
    async delgoods(e) {
        // 阻止事件冒泡
        e.stopPropagation();
        
        const param = e.currentTarget.dataset.param;
        wx.showLoading({
            title: '正在下架，请稍候...',
        });
        
        try {
            // 先从goods集合获取要下架商品的数据
            const res = await db.collection("goods").doc(param).get()
            
            // 将数据存入downs集合
            const { _id, _openid, ...goodsData } = res.data;
            await db.collection("downs").add({
                data: {
                    ...goodsData,
                    downTime: new Date().toLocaleString(),
                    originalGoodsId: param
                }
            })
            
            // 再从goods集合删除该商品
            await db.collection("goods").doc(param).remove()
            
            wx.hideLoading();
            wx.showToast({
                title: '下架成功!',
            });
            
            // 更新页面数据
            this.getData();
            // 通知center页面更新数量
            getApp().globalData.needRefresh = true;
        } catch (err) {
            console.log(err);
            wx.hideLoading();
            wx.showToast({
                title: '下架失败，请稍后重试',
                icon: 'none'
            });
        }
    },
    
    // 重新上架商品
    async relistGoods(e) {
        // 阻止事件冒泡
        e.stopPropagation();
        
        const param = e.currentTarget.dataset.param;
        const originalGoodsId = e.currentTarget.dataset.original;
        
        wx.showLoading({
            title: '正在上架，请稍候...',
        });
        
        try {
            // 从downs集合获取要重新上架的商品数据
            const res = await db.collection("downs").doc(param).get()
            
            // 将数据重新添加到goods集合
            const { _id, _openid, downTime, originalGoodsId: originalId, ...goodsData } = res.data;
            await db.collection("goods").add({
                data: {
                    ...goodsData,
                    postTime: new Date().toISOString(),
                    showtime: new Date().toLocaleString(),
                    status: 'on_sale',
                    saleStatus: 'available'
                }
            })
            
            // 从downs集合删除该商品
            await db.collection("downs").doc(param).remove()
            
            wx.hideLoading();
            wx.showToast({
                title: '上架成功!',
            });
            
            // 更新页面数据
            this.getDownGoods();
            // 通知center页面更新数量
            getApp().globalData.needRefresh = true;
        } catch (err) {
            console.log(err);
            wx.hideLoading();
            wx.showToast({
                title: '上架失败，请稍后重试',
                icon: 'none'
            });
        }
    },
    
    // 查看商品详情
    viewDetail(e) {
        const goodsId = e.currentTarget.dataset.id;
        wx.navigateTo({
            url: `/pages/detail/detail?id=${goodsId}`
        });
    },
    
    // 阻止事件冒泡
    stopPropagation(e) {
        e.stopPropagation();
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
        this.getData()
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {
        // 检查是否需要刷新数据
        if (getApp().globalData.needRefresh) {
            if (this.data.classup) {
                this.getData();
            } else {
                this.getDownGoods();
            }
            getApp().globalData.needRefresh = false;
        }
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {
        if (this.data.classup) {
            this.getData();
        } else {
            this.getDownGoods();
        }
        // 数据加载完成后，停止下拉刷新动画
        wx.stopPullDownRefresh();
        wx.showToast({
            title: '刷新成功!',
            icon: "success"
        })
    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})