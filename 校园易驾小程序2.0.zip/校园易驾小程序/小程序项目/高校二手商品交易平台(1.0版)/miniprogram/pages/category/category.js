// pages/category/category.js
const app = getApp();

Page({
  data: {
    // 功能导航
    functionNavs: [
      { id: 'buy', name: '买车', icon: '../../images/buy-icon.png' },
      { id: 'sell', name: '卖车', icon: '../../images/sell-icon.png' },
      { id: 'rent', name: '租车', icon: '../../images/rent-icon.png' },
      { id: 'service', name: '售后', icon: '../../images/service-icon.png' }
    ],
    activeNav: 'buy',
    
    // 地区选择
    selectedLocation: '广州大学城',
    showLocationPicker: false,
    locationOptions: [
      { value: 'gzu', label: '广州大学城' },
      { value: 'thu', label: '清华大学' },
      { value: 'pku', label: '北京大学' },
      { value: 'fdu', label: '复旦大学' },
      { value: 'sjtu', label: '上海交通大学' }
    ],
    
    // 排序和筛选
    sortType: 'default',
    showFilterPanel: false,
    activeFilterCount: 0,
    activeFilters: [],
    
    // 筛选条件
    filters: {
      priceRange: [null, null],
      brands: [],
      ranges: [],
      ages: [],
      hasInsurance: null,
      conditions: []
    },
    
    // 筛选选项
    priceRange: ['', ''],
    selectedBrands: [],
    selectedRanges: [],
    selectedAges: [],
    selectedInsurance: null,
    selectedConditions: [],
    
    brandOptions: [
      { value: 'yadea', label: '雅迪' },
      { value: 'aima', label: '爱玛' },
      { value: 'xinyri', label: '新日' },
      { value: 'tailg', label: '台铃' },
      { value: 'luyuan', label: '绿源' },
      { value: 'ninebot', label: '九号' },
      { value: 'xiaomi', label: '小米' },
      { value: 'other', label: '其他' }
    ],
    rangeOptions: [
      { value: '0-30', label: '30km以下' },
      { value: '30-50', label: '30-50km' },
      { value: '50-70', label: '50-70km' },
      { value: '70-100', label: '70-100km' },
      { value: '100+', label: '100km以上' }
    ],
    ageOptions: [
      { value: '0-1', label: '1年以内' },
      { value: '1-2', label: '1-2年' },
      { value: '2-3', label: '2-3年' },
      { value: '3+', label: '3年以上' }
    ],
    conditionOptions: [
      { value: 'new', label: '全新' },
      { value: 'excellent', label: '优秀' },
      { value: 'good', label: '良好' },
      { value: 'fair', label: '一般' }
    ],
    
    // 商品数据
    allGoods: [],
    filteredGoods: [],
    page: 1,
    pageSize: 10,
    hasMore: true,
    isLoading: false
  },

  onLoad: function(options) {
    this.loadAllGoods();
  },

  onShow: function() {
    this.setData({
      islogin: wx.getStorageSync('islogin')
    });
  },

  // 阻止触摸事件冒泡
  preventTouchMove: function() {
    // 空函数，仅用于阻止事件冒泡
    return;
  },

  // 切换功能导航
  switchNav: function(e) {
    const navId = e.currentTarget.dataset.id;
    this.setData({ activeNav: navId });
    
    // 根据不同导航显示不同内容
    if (navId === 'sell') {
      wx.navigateTo({
        url: '/pages/publish/publish'
      });
    } else if (navId === 'service') {
      wx.navigateTo({
        url: '/pages/service/service'
      });
    }
  },

  // 显示地区选择器
  showLocationPicker: function() {
    this.setData({ showLocationPicker: true });
  },

  // 隐藏地区选择器
  hideLocationPicker: function() {
    this.setData({ showLocationPicker: false });
  },

  // 选择地区
  selectLocation: function(e) {
    const { value, label } = e.currentTarget.dataset;
    this.setData({
      selectedLocation: label,
      showLocationPicker: false
    });
    
    // 根据地区筛选商品
    this.applyFilters();
  },

  // 切换排序方式
  changeSort: function(e) {
    const sortType = e.currentTarget.dataset.type;
    this.setData({ sortType });
    this.applyFilters();
  },

  // 显示筛选面板
  toggleFilterPanel: function() {
    this.setData({ showFilterPanel: !this.data.showFilterPanel });
  },

  // 隐藏筛选面板
  hideFilterPanel: function() {
    this.setData({ showFilterPanel: false });
  },

  // 最低价格输入
  onMinPriceInput: function(e) {
    const value = e.detail.value;
    this.setData({
      'priceRange[0]': value
    });
  },

  // 最高价格输入
  onMaxPriceInput: function(e) {
    const value = e.detail.value;
    this.setData({
      'priceRange[1]': value
    });
  },

  // 切换品牌选择
  toggleBrand: function(e) {
    const value = e.currentTarget.dataset.value;
    let selectedBrands = [...this.data.selectedBrands];
    
    if (selectedBrands.includes(value)) {
      const index = selectedBrands.indexOf(value);
      selectedBrands.splice(index, 1);
    } else {
      selectedBrands.push(value);
    }
    
    this.setData({ selectedBrands });
    console.log('Selected brands:', selectedBrands); // 调试日志
  },

  // 切换续航选择
  toggleRange: function(e) {
    const value = e.currentTarget.dataset.value;
    let selectedRanges = [...this.data.selectedRanges];
    
    if (selectedRanges.includes(value)) {
      const index = selectedRanges.indexOf(value);
      selectedRanges.splice(index, 1);
    } else {
      selectedRanges.push(value);
    }
    
    this.setData({ selectedRanges });
    console.log('Selected ranges:', selectedRanges); // 调试日志
  },

  // 切换车龄选择
  toggleAge: function(e) {
    const value = e.currentTarget.dataset.value;
    let selectedAges = [...this.data.selectedAges];
    
    if (selectedAges.includes(value)) {
      const index = selectedAges.indexOf(value);
      selectedAges.splice(index, 1);
    } else {
      selectedAges.push(value);
    }
    
    this.setData({ selectedAges });
    console.log('Selected ages:', selectedAges); // 调试日志
  },

  // 切换保险选择
  toggleInsurance: function(e) {
    const value = e.currentTarget.dataset.value;
    this.setData({
      selectedInsurance: this.data.selectedInsurance === value ? null : value
    });
    console.log('Selected insurance:', this.data.selectedInsurance); // 调试日志
  },

  // 切换车况选择
  toggleCondition: function(e) {
    const value = e.currentTarget.dataset.value;
    let selectedConditions = [...this.data.selectedConditions];
    
    if (selectedConditions.includes(value)) {
      const index = selectedConditions.indexOf(value);
      selectedConditions.splice(index, 1);
    } else {
      selectedConditions.push(value);
    }
    
    this.setData({ selectedConditions });
    console.log('Selected conditions:', selectedConditions); // 调试日志
  },

  // 应用筛选条件
  applyFilters: function() {
    // 更新筛选条件
    const minPrice = this.data.priceRange[0] ? parseInt(this.data.priceRange[0]) : null;
    const maxPrice = this.data.priceRange[1] ? parseInt(this.data.priceRange[1]) : null;
    
    const filters = {
      priceRange: [minPrice, maxPrice],
      brands: this.data.selectedBrands,
      ranges: this.data.selectedRanges,
      ages: this.data.selectedAges,
      hasInsurance: this.data.selectedInsurance,
      conditions: this.data.selectedConditions
    };
    
    this.setData({ filters });
    
    // 生成活跃筛选条件显示
    const activeFilters = [];
    let activeFilterCount = 0;
    
    // 价格筛选
    if (minPrice !== null || maxPrice !== null) {
      let priceLabel = '价格';
      if (minPrice !== null && maxPrice !== null) {
        priceLabel += `: ${minPrice}-${maxPrice}元`;
      } else if (minPrice !== null) {
        priceLabel += `: ${minPrice}元以上`;
      } else if (maxPrice !== null) {
        priceLabel += `: ${maxPrice}元以下`;
      }
      
      activeFilters.push({ key: 'price', label: '价格', value: `${minPrice || ''}-${maxPrice || ''}` });
      activeFilterCount++;
    }
    
    // 品牌筛选
    if (filters.brands.length > 0) {
      const brandLabels = filters.brands.map(brand => {
        const option = this.data.brandOptions.find(opt => opt.value === brand);
        return option ? option.label : brand;
      });
      
      activeFilters.push({ 
        key: 'brands', 
        label: '品牌', 
        value: brandLabels.join(',') 
      });
      activeFilterCount++;
    }
    
    // 续航筛选
    if (filters.ranges.length > 0) {
      const rangeLabels = filters.ranges.map(range => {
        const option = this.data.rangeOptions.find(opt => opt.value === range);
        return option ? option.label : range;
      });
      
      activeFilters.push({ 
        key: 'ranges', 
        label: '续航', 
        value: rangeLabels.join(',') 
      });
      activeFilterCount++;
    }
    
    // 车龄筛选
    if (filters.ages.length > 0) {
      const ageLabels = filters.ages.map(age => {
        const option = this.data.ageOptions.find(opt => opt.value === age);
        return option ? option.label : age;
      });
      
      activeFilters.push({ 
        key: 'ages', 
        label: '车龄', 
        value: ageLabels.join(',') 
      });
      activeFilterCount++;
    }
    
    // 保险筛选
    if (filters.hasInsurance !== null) {
      activeFilters.push({ 
        key: 'hasInsurance', 
        label: '保险', 
        value: filters.hasInsurance === 'true' ? '有' : '无' 
      });
      activeFilterCount++;
    }
    
    // 车况筛选
    if (filters.conditions.length > 0) {
      const conditionLabels = filters.conditions.map(condition => {
        const option = this.data.conditionOptions.find(opt => opt.value === condition);
        return option ? option.label : condition;
      });
      
      activeFilters.push({ 
        key: 'conditions', 
        label: '车况', 
        value: conditionLabels.join(',') 
      });
      activeFilterCount++;
    }
    
    // 筛选商品
    let filteredGoods = [...this.data.allGoods];
    
    // 价格筛选
    if (filters.priceRange[0] !== null || filters.priceRange[1] !== null) {
      filteredGoods = filteredGoods.filter(item => {
        if (filters.priceRange[0] !== null && item.price < filters.priceRange[0]) {
          return false;
        }
        if (filters.priceRange[1] !== null && item.price > filters.priceRange[1]) {
          return false;
        }
        return true;
      });
    }
    
    // 品牌筛选 - 修复品牌匹配问题
    if (filters.brands.length > 0) {
      // 创建品牌值到中文名的映射
      const brandMapping = {
        'yadea': '雅迪',
        'aima': '爱玛',
        'xinyri': '新日',
        'tailg': '台铃',
        'luyuan': '绿源',
        'ninebot': '九号',
        'xiaomi': '小米',
        'other': '其他'
      };
      
      filteredGoods = filteredGoods.filter(item => {
        // 获取商品品牌的中文名
        const itemBrand = item.brand;
        
        // 检查是否有选中的品牌与商品品牌匹配
        return filters.brands.some(brandValue => {
          const brandName = brandMapping[brandValue];
          return itemBrand === brandName;
        });
      });
    }
    
    // 续航筛选
    if (filters.ranges.length > 0) {
      filteredGoods = filteredGoods.filter(item => {
        return filters.ranges.some(range => {
          if (range === '0-30') return item.range < 30;
          if (range === '30-50') return item.range >= 30 && item.range < 50;
          if (range === '50-70') return item.range >= 50 && item.range < 70;
          if (range === '70-100') return item.range >= 70 && item.range < 100;
          if (range === '100+') return item.range >= 100;
          return false;
        });
      });
    }
    
    // 车龄筛选
    if (filters.ages.length > 0) {
      filteredGoods = filteredGoods.filter(item => {
        return filters.ages.some(age => {
          if (age === '0-1') return item.age < 1;
          if (age === '1-2') return item.age >= 1 && item.age < 2;
          if (age === '2-3') return item.age >= 2 && item.age < 3;
          if (age === '3+') return item.age >= 3;
          return false;
        });
      });
    }
    
    // 保险筛选
    if (filters.hasInsurance !== null) {
      filteredGoods = filteredGoods.filter(item => 
        item.hasInsurance === (filters.hasInsurance === 'true')
      );
    }
    
    // 车况筛选
    if (filters.conditions.length > 0) {
      filteredGoods = filteredGoods.filter(item => 
        filters.conditions.includes(item.condition)
      );
    }
    
    // 地区筛选
    filteredGoods = filteredGoods.filter(item => 
      item.location === this.data.selectedLocation
    );
    
    // 排序
    filteredGoods = this.applySorting(filteredGoods);
    
    // 更新数据
    this.setData({
      filteredGoods,
      activeFilters,
      activeFilterCount,
      showFilterPanel: false,
      page: 1,
      hasMore: filteredGoods.length > this.data.pageSize
    });
  },

  // 应用排序
  applySorting: function(goodsList) {
    const sortType = this.data.sortType;
    
    switch(sortType) {
      case 'price_asc':
        return goodsList.sort((a, b) => a.price - b.price);
      case 'price_desc':
        return goodsList.sort((a, b) => b.price - a.price);
      case 'newest':
        return goodsList.sort((a, b) => new Date(b.postTime) - new Date(a.postTime));
      default:
        return goodsList;
    }
  },

  // 移除单个筛选条件
  removeFilter: function(e) {
    const key = e.currentTarget.dataset.key;
    
    if (key === 'price') {
      this.setData({
        'priceRange': ['', '']
      });
    } else if (key === 'brands') {
      this.setData({
        selectedBrands: []
      });
    } else if (key === 'ranges') {
      this.setData({
        selectedRanges: []
      });
    } else if (key === 'ages') {
      this.setData({
        selectedAges: []
      });
    } else if (key === 'hasInsurance') {
      this.setData({
        selectedInsurance: null
      });
    } else if (key === 'conditions') {
      this.setData({
        selectedConditions: []
      });
    }
    
    // 重新应用筛选
    this.applyFilters();
  },

  // 清除所有筛选条件
  clearAllFilters: function() {
    this.setData({
      priceRange: ['', ''],
      selectedBrands: [],
      selectedRanges: [],
      selectedAges: [],
      selectedInsurance: null,
      selectedConditions: [],
      activeFilters: [],
      activeFilterCount: 0,
      sortType: 'default'
    });
    
    // 重新应用筛选
    this.applyFilters();
  },

  // 加载更多商品
  loadMore: function() {
    if (this.data.isLoading || !this.data.hasMore) return;
    
    this.setData({
      isLoading: true,
      page: this.data.page + 1
    });
    
    // 模拟加载更多数据
    setTimeout(() => {
      const startIndex = (this.data.page - 1) * this.data.pageSize;
      const endIndex = startIndex + this.data.pageSize;
      const moreGoods = this.data.filteredGoods.slice(0, endIndex);
      
      this.setData({
        filteredGoods: moreGoods,
        isLoading: false,
        hasMore: endIndex < this.data.filteredGoods.length
      });
    }, 1000);
  },

  // 格式化时间
  formatTime: function(dateString) {
    if (!dateString) return '';
    
    const date = new Date(dateString);
    const now = new Date();
    const diff = now - date;
    const minutes = Math.floor(diff / (1000 * 60));
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    
    if (minutes < 1) {
      return '刚刚';
    } else if (minutes < 60) {
      return `${minutes}分钟前`;
    } else if (hours < 24) {
      return `${hours}小时前`;
    } else if (days < 7) {
      return `${days}天前`;
    } else {
      return `${date.getMonth() + 1}月${date.getDate()}日`;
    }
  },

  // 跳转到详情页
  toDetail: function(e) {
    const goods_id = e.currentTarget.dataset.id;
    const hitFn = require("../../utils/index");
    hitFn.updateHit(this.data.islogin, goods_id);
    
    wx.navigateTo({
      url: `/pages/goods/goods?goods_id=${goods_id}`
    });
  },

  // 跳转到搜索页
  toSearch: function() {
    wx.navigateTo({
      url: "/pages/search/search"
    });
  },

  // 加载所有商品
  loadAllGoods: function() {
    // 示例数据 - 两个具体的商品
    const sampleGoods = [
      {
        _id: '1',
        title: '九号电动自行车C40 智能电动车',
        price: 1599,
        originalPrice: 2299,
        brand: '九号',
        range: 45,
        age: 1,
        isCertified: true,
        hasInsurance: true,
        canTestRide: true,
        location: '广州大学城',
        postTime: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
        images: ['../../images/sample-bike-1.jpg'],
        condition: 'excellent',
        description: '九号电动自行车C40，智能电动车，续航45km，车龄1年，有保险，支持试骑。车辆状况良好，无任何事故。',
        seller: {
          name: '张同学',
          avatar: '../../images/avatar1.jpg',
          rating: 4.8,
          sales: 12
        },
        contact: '13800138000'
      },
      {
        _id: '2',
        title: '雅迪欧逸新国标电动车',
        price: 1299,
        originalPrice: 1799,
        brand: '雅迪',
        range: 60,
        age: 2,
        isCertified: true,
        hasInsurance: false,
        canTestRide: true,
        location: '广州大学城',
        postTime: new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString(),
        images: ['../../images/sample-bike-2.jpg'],
        condition: 'good',
        description: '雅迪欧逸新国标电动车，续航60km，车龄2年，无保险，支持试骑。车辆状况良好，电池健康度85%。',
        seller: {
          name: '李同学',
          avatar: '../../images/avatar2.jpg',
          rating: 4.5,
          sales: 8
        },
        contact: '13900139000'
      }
    ];
    
    this.setData({
      allGoods: sampleGoods,
      filteredGoods: sampleGoods
    });
  }
});