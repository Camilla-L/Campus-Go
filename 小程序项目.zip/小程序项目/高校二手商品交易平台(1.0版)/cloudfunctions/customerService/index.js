const cloud = require('wx-server-sdk')
cloud.init()

// 客服消息自动回复规则
const autoReplyRules = {
  '你好': '您好！欢迎咨询二手车相关信息，请问有什么可以帮您？',
  '您好': '您好！我是智能客服，很高兴为您服务。',
  '价格': '我们的车辆价格都是经过专业评估的，您可以在商品详情页查看具体价格信息。',
  '优惠': '目前我们有新用户专享优惠，注册即可获得200元优惠券！',
  '联系方式': '客服电话：400-123-4567（工作日9:00-18:00）',
  '地址': '我们的实体店地址：北京市朝阳区汽车城A座101室',
  '检测': '所有车辆都经过128项专业检测，确保车况透明。',
  '保修': '我们提供7天无理由退换，1年或2万公里质保服务。',
  '贷款': '我们支持多种贷款方案，首付最低20%，最快2小时放款。',
  '车型': '我们提供各种品牌车型，包括轿车、SUV、MPV等，您有什么偏好的车型吗？',
  '品牌': '我们经营多个品牌二手车，包括宝马、奔驰、奥迪、丰田、本田等主流品牌。'
}

exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext()
  const { MsgType, Content } = event
  
  console.log('收到客服消息:', { MsgType, Content, openid: wxContext.OPENID })
  
  // 只处理文本消息
  if (MsgType === 'text') {
    const userMessage = Content.trim().toLowerCase()
    let replyContent = '感谢您的咨询！如果您需要了解车辆信息、价格、优惠活动、贷款方案等，请告诉我具体问题，我会尽力为您解答。'
    
    // 匹配关键词回复
    for (const [keyword, reply] of Object.entries(autoReplyRules)) {
      if (userMessage.includes(keyword.toLowerCase())) {
        replyContent = reply
        break
      }
    }
    
    // 添加一些随机欢迎语
    const welcomeMessages = [
      '🚗 专业二手车服务平台，为您提供优质购车体验！',
      '🔧 所有车辆经过专业检测，车况透明放心！',
      '💰 多种贷款方案，低首付轻松购车！',
      '🎁 新用户注册即送200元优惠券！',
      '⭐ 7天无理由退换，购车无忧！'
    ]
    
    const randomWelcome = welcomeMessages[Math.floor(Math.random() * welcomeMessages.length)]
    
    return {
      ToUserName: wxContext.OPENID,
      FromUserName: wxContext.FROM_OPENID,
      CreateTime: Math.floor(Date.now() / 1000),
      MsgType: 'text',
      Content: `${replyContent}\n\n${randomWelcome}`
    }
  }
  
  // 默认回复
  return {
    ToUserName: wxContext.OPENID,
    FromUserName: wxContext.FROM_OPENID,
    CreateTime: Math.floor(Date.now() / 1000),
    MsgType: 'text',
    Content: '您好！我是智能客服，请问有什么可以帮助您的？\n\n🚗 专业二手车服务，购车更放心！'
  }
}