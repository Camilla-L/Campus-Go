const db = wx.cloud.database()
Page({

    /**
     * 页面的初始数据
     */
    data: {
        orderList: [],
        isLoading: true,
        isShow: false,
        contents: "暂无订单数据",
        selectedTab: 'all', // 全部订单
        activeMenuIndex: -1, // 当前激活的菜单索引
        tabs: [
            { key: 'all', name: '全部订单' },
            { key: 'pending', name: '待付款' },
            { key: 'shipped', name: '待收货' },
            { key: 'completed', name: '已完成' },
            { key: 'refunding', name: '退款/售后' }
        ]
    },

    // 切换订单状态标签
    switchTab(e) {
        const tab = e.currentTarget.dataset.tab;
        this.setData({
            selectedTab: tab,
            isLoading: true,
            activeMenuIndex: -1 // 关闭所有菜单
        });
        this.getOrders(tab);
    },

    // 获取订单数据
    getOrders(status = 'all') {
        const buyerId = wx.getStorageSync('id');
        if (!buyerId) {
            this.setData({
                isLoading: false,
                isShow: true,
                contents: "请先登录"
            });
            return;
        }

        let query = { buyerId: buyerId };
        
        // 根据状态筛选
        if (status !== 'all') {
            query.status = status;
        }

        db.collection("orders")
            .where(query)
            .orderBy('createTime', 'desc')
            .get()
            .then(res => {
                if (res.data.length === 0) {
                    this.setData({
                        isShow: true,
                        contents: "暂无订单数据",
                        orderList: [],
                        isLoading: false
                    });
                } else {
                    this.setData({
                        orderList: res.data,
                        isShow: false,
                        isLoading: false
                    });
                }
            })
            .catch(err => {
                console.error("获取订单失败", err);
                this.setData({
                    isLoading: false,
                    isShow: true,
                    contents: "获取订单失败，请重试"
                });
                wx.showToast({
                    title: '获取订单失败',
                    icon: 'none'
                });
            });
    },

    // 查看商品详情
    viewGoodsDetail(e) {
        const goodsId = e.currentTarget.dataset.id;
        wx.navigateTo({
            url: `/pages/detail/detail?id=${goodsId}`
        });
    },

    // 查看订单详情
    viewOrderDetail(e) {
        const orderId = e.currentTarget.dataset.id;
        this.closeMenu(); // 关闭菜单
        wx.navigateTo({
            url: `/pages/orderDetail/orderDetail?id=${orderId}&role=buyer`
        });
    },

    // 联系卖家
    contactSeller(e) {
        const sellerId = e.currentTarget.dataset.sellerid;
        const orderId = e.currentTarget.dataset.orderid;
        this.closeMenu(); // 关闭菜单
        
        wx.navigateTo({
            url: `/pages/contact/contact?targetId=${sellerId}&orderId=${orderId}`
        });
    },

    // 催发货
    urgeShipment(e) {
        const orderId = e.currentTarget.dataset.id;
        const order = this.data.orderList.find(item => item._id === orderId);
        this.closeMenu(); // 关闭菜单
        
        if (!order) return;
        
        wx.showModal({
            title: '提醒发货',
            content: `确定要提醒卖家「${order.sellerName}」尽快发货吗？`,
            success: async (res) => {
                if (res.confirm) {
                    wx.showLoading({
                        title: '发送中...',
                    });
                    
                    try {
                        // 发送消息给卖家
                        await db.collection("messages").add({
                            data: {
                                type: 'urge_shipment',
                                title: '买家提醒发货',
                                content: `买家提醒您尽快发货订单 ${order.orderNumber}`,
                                senderId: wx.getStorageSync('id'),
                                senderName: wx.getStorageSync('uname'),
                                receiverId: order.sellerId,
                                relatedId: orderId,
                                isRead: false,
                                createTime: new Date().toISOString()
                            }
                        });
                        
                        wx.hideLoading();
                        wx.showToast({
                            title: '已提醒卖家发货',
                            icon: 'success'
                        });
                    } catch (error) {
                        console.error('发送提醒失败:', error);
                        wx.hideLoading();
                        wx.showToast({
                            title: '发送失败，请重试',
                            icon: 'none'
                        });
                    }
                }
            }
        });
    },

    // 确认收货
    confirmReceipt(e) {
        const orderId = e.currentTarget.dataset.id;
        this.closeMenu(); // 关闭菜单
        
        wx.showModal({
            title: '确认收货',
            content: '请确认您已收到商品，确认后将完成交易',
            success: async (res) => {
                if (res.confirm) {
                    wx.showLoading({
                        title: '处理中...',
                    });

                    try {
                        // 更新订单状态为已完成
                        await db.collection("orders").doc(orderId).update({
                            data: {
                                status: 'completed',
                                completeTime: new Date().toISOString()
                            }
                        });
                        
                        // 更新商品状态为已售出
                        const orderRes = await db.collection("orders").doc(orderId).get();
                        const order = orderRes.data;
                        
                        if (order.goodsId) {
                            await db.collection("goods").doc(order.goodsId).update({
                                data: {
                                    saleStatus: 'sold'
                                }
                            });
                        }

                        wx.hideLoading();
                        wx.showToast({
                            title: '确认收货成功',
                            icon: 'success'
                        });

                        // 刷新订单列表
                        this.getOrders(this.data.selectedTab);
                    } catch (error) {
                        console.error('确认收货失败:', error);
                        wx.hideLoading();
                        wx.showToast({
                            title: '操作失败，请重试',
                            icon: 'none'
                        });
                    }
                }
            }
        });
    },

    // 申请退款
    applyRefund(e) {
        const orderId = e.currentTarget.dataset.id;
        const order = this.data.orderList.find(item => item._id === orderId);
        this.closeMenu(); // 关闭菜单
        
        if (!order) return;
        
        wx.showModal({
            title: '申请退款',
            content: `确定要申请退款订单「${order.orderNumber}」吗？`,
            success: async (res) => {
                if (res.confirm) {
                    wx.showLoading({
                        title: '处理中...',
                    });
                    
                    try {
                        // 更新订单状态为退款中
                        await db.collection("orders").doc(orderId).update({
                            data: {
                                status: 'refunding',
                                refundApplyTime: new Date().toISOString()
                            }
                        });
                        
                        // 发送退款申请消息给卖家
                        await db.collection("messages").add({
                            data: {
                                type: 'refund_apply',
                                title: '退款申请',
                                content: `买家申请退款订单 ${order.orderNumber}，请及时处理`,
                                senderId: wx.getStorageSync('id'),
                                senderName: wx.getStorageSync('uname'),
                                receiverId: order.sellerId,
                                relatedId: orderId,
                                isRead: false,
                                createTime: new Date().toISOString()
                            }
                        });
                        
                        wx.hideLoading();
                        wx.showToast({
                            title: '退款申请已提交',
                            icon: 'success'
                        });
                        
                        // 刷新订单列表
                        this.getOrders(this.data.selectedTab);
                    } catch (error) {
                        console.error('申请退款失败:', error);
                        wx.hideLoading();
                        wx.showToast({
                            title: '操作失败，请重试',
                            icon: 'none'
                        });
                    }
                }
            }
        });
    },

    // 修改地址
    modifyAddress(e) {
        const orderId = e.currentTarget.dataset.id;
        this.closeMenu(); // 关闭菜单
        
        wx.navigateTo({
            url: `/pages/address/address?orderId=${orderId}&mode=modify`
        });
    },

    // 取消订单
    cancelOrder(e) {
        const orderId = e.currentTarget.dataset.id;
        const order = this.data.orderList.find(item => item._id === orderId);
        this.closeMenu(); // 关闭菜单
        
        if (!order) return;
        
        wx.showModal({
            title: '取消订单',
            content: `确定要取消订单「${order.orderNumber}」吗？`,
            success: async (res) => {
                if (res.confirm) {
                    wx.showLoading({
                        title: '处理中...',
                    });
                    
                    try {
                        // 更新订单状态为已取消
                        await db.collection("orders").doc(orderId).update({
                            data: {
                                status: 'cancelled',
                                cancelTime: new Date().toISOString()
                            }
                        });
                        
                        // 更新商品状态为在售
                        if (order.goodsId) {
                            await db.collection("goods").doc(order.goodsId).update({
                                data: {
                                    saleStatus: 'onSale'
                                }
                            });
                        }
                        
                        // 发送取消订单消息给卖家
                        await db.collection("messages").add({
                            data: {
                                type: 'order_cancel',
                                title: '订单已取消',
                                content: `买家取消了订单 ${order.orderNumber}`,
                                senderId: wx.getStorageSync('id'),
                                senderName: wx.getStorageSync('uname'),
                                receiverId: order.sellerId,
                                relatedId: orderId,
                                isRead: false,
                                createTime: new Date().toISOString()
                            }
                        });
                        
                        wx.hideLoading();
                        wx.showToast({
                            title: '订单已取消',
                            icon: 'success'
                        });
                        
                        // 刷新订单列表
                        this.getOrders(this.data.selectedTab);
                    } catch (error) {
                        console.error('取消订单失败:', error);
                        wx.hideLoading();
                        wx.showToast({
                            title: '操作失败，请重试',
                            icon: 'none'
                        });
                    }
                }
            }
        });
    },

    // 再次购买
    buyAgain(e) {
        const goodsId = e.currentTarget.dataset.id;
        this.closeMenu(); // 关闭菜单
        
        wx.navigateTo({
            url: `/pages/detail/detail?id=${goodsId}`
        });
    },

    // 查看物流
    viewLogistics(e) {
        const orderId = e.currentTarget.dataset.id;
        this.closeMenu(); // 关闭菜单
        
        wx.showModal({
            title: '物流信息',
            content: '物流信息查询功能需要对接物流API，当前暂未开放',
            showCancel: false
        });
    },

    // 评价订单
    rateOrder(e) {
        const orderId = e.currentTarget.dataset.id;
        this.closeMenu(); // 关闭菜单
        
        wx.navigateTo({
            url: `/pages/rating/rating?orderId=${orderId}`
        });
    },

    // 格式化时间
    formatTime(dateString) {
        if (!dateString) return '';
        
        const date = new Date(dateString);
        const now = new Date();
        const diff = now - date;
        const minutes = Math.floor(diff / (1000 * 60));
        const hours = Math.floor(diff / (1000 * 60 * 60));
        const days = Math.floor(diff / (1000 * 60 * 60 * 24));
        
        if (minutes < 1) {
            return '刚刚';
        } else if (minutes < 60) {
            return `${minutes}分钟前`;
        } else if (hours < 24) {
            return `${hours}小时前`;
        } else if (days < 7) {
            return `${days}天前`;
        } else {
            return `${date.getMonth() + 1}月${date.getDate()}日 ${date.getHours()}:${date.getMinutes()}`;
        }
    },

    // 切换菜单显示
    toggleMenu(e) {
        const index = e.currentTarget.dataset.index;
        this.setData({
            activeMenuIndex: this.data.activeMenuIndex === index ? -1 : index
        });
    },

    // 关闭菜单
    closeMenu() {
        this.setData({
            activeMenuIndex: -1
        });
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
        this.getOrders();
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {
        // 页面显示时刷新数据
        this.getOrders(this.data.selectedTab);
        // 关闭所有菜单
        this.closeMenu();
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {
        // 关闭所有菜单
        this.closeMenu();
    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {
        this.getOrders(this.data.selectedTab);
        wx.stopPullDownRefresh();
    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})