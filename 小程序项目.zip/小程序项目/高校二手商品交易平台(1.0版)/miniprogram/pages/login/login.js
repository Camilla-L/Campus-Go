const db = wx.cloud.database()

Page({

    /**
     * 页面的初始数据
     */
    data: {
        ischecked: true,
        passwordType:true
    },
    // 勾选协议的逻辑
    togglechecked() {
        this.setData({
            ischecked: this.data.ischecked ? false : true
        })
    },
    // 登录逻辑
    login(e) {
        const formData = e.detail.value
        if (formData.username === "" || formData.password === "") {
            wx.showToast({
                title: '表单须填写完整',
                icon: 'error'
            })
            return;
        }
        if (!this.data.ischecked) {
            wx.showToast({
                title: '请勾选协议',
                icon: 'error'
            })
            return;
        }

        // openid进行身份鉴权
        db.collection("users").where({
            tel: formData.username,
            pwd: formData.password
        }).get().then(res => {
            if (res.data.length === 1) {
                wx.showToast({
                    title: '登陆成功!',
                    icon: "success"
                })
                const _id = res.data[0]._id.slice(0, 5)
                wx.setStorageSync('userId', _id)
                wx.setStorageSync('id', res.data[0]._id)
                wx.setStorageSync('avator', res.data[0].avator)
                wx.setStorageSync('uname', res.data[0].uname)
                wx.setStorageSync('tel', res.data[0].tel)
                wx.setStorageSync('islogin', true)
                setTimeout(() => {
                    wx.switchTab({
                        url: '/pages/index/index',
                    })
                }, 1000)
            } else {
                wx.showToast({
                    title: '账号或密码错误!',
                    icon: "error"
                })
            }
        })

    },
   

    // 点击隐藏或显示密码
    changeType(e){
        this.setData({
            passwordType:!this.data.passwordType,
        })
    },


    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {

    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    },
})