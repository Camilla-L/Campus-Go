const db = wx.cloud.database()
Page({

    /**
     * 页面的初始数据
     */
    data: {
        orderId: null,
        orderData: null,
        role: 'seller', // seller或buyer
        isLoading: true
    },

    // 格式化时间
    formatTime(timestamp) {
        if (!timestamp) return '';
        const date = new Date(timestamp);
        return `${date.getFullYear()}-${(date.getMonth() + 1).toString().padStart(2, '0')}-${date.getDate().toString().padStart(2, '0')} ${date.getHours().toString().padStart(2, '0')}:${date.getMinutes().toString().padStart(2, '0')}`;
    },

    // 获取订单详情
    getOrderDetail() {
        db.collection("orders").doc(this.data.orderId).get()
            .then(res => {
                this.setData({
                    orderData: res.data,
                    isLoading: false
                });
            })
            .catch(err => {
                console.error("获取订单详情失败", err);
                this.setData({
                    isLoading: false
                });
                wx.showToast({
                    title: '获取订单详情失败',
                    icon: 'none'
                });
            });
    },

    // 联系对方
    contactOther() {
        const phone = this.data.role === 'seller' ? 
                     this.data.orderData.buyerPhone : 
                     this.data.orderData.sellerPhone;
        
        if (phone) {
            wx.makePhoneCall({
                phoneNumber: phone
            });
        } else {
            wx.showToast({
                title: '未提供联系方式',
                icon: 'none'
            });
        }
    },

    // 发送消息给对方
    messageOther() {
        const contactId = this.data.role === 'seller' ? 
                         this.data.orderData.buyerId : 
                         this.data.orderData.sellerId;
        const contactName = this.data.role === 'seller' ? 
                           this.data.orderData.buyerName : 
                           this.data.orderData.sellerName;
        
        wx.showModal({
            title: '联系对方',
            content: `确定要联系${this.data.role === 'seller' ? '买家' : '卖家'}「${contactName}」吗？`,
            success: (res) => {
                if (res.confirm) {
                    // 这里可以集成即时通讯功能
                    // 暂时使用复制ID的方式
                    wx.setClipboardData({
                        data: `${this.data.role === 'seller' ? '买家' : '卖家'}ID: ${contactId}`,
                        success: () => {
                            wx.showToast({
                                title: 'ID已复制，请使用其他方式联系',
                                icon: 'success'
                            });
                        }
                    });
                }
            }
        });
    },

    // 更新订单状态
    updateOrderStatus(e) {
        const { status } = e.currentTarget.dataset;
        const statusText = {
            'pending': '确认发货',
            'shipped': '确认收货',
            'completed': '已完成'
        }[status] || '处理';

        wx.showModal({
            title: '确认操作',
            content: `确定要${statusText}吗？`,
            success: async (res) => {
                if (res.confirm) {
                    wx.showLoading({
                        title: '处理中...',
                    });

                    try {
                        let updateData = {};
                        
                        if (status === 'pending') {
                            updateData.status = 'shipped';
                            updateData.shipTime = new Date().toISOString();
                        } else if (status === 'shipped') {
                            updateData.status = 'completed';
                            updateData.completeTime = new Date().toISOString();
                            
                            // 订单完成时，将商品状态改为已售出
                            if (this.data.orderData && this.data.orderData.goodsId) {
                                await db.collection("goods").doc(this.data.orderData.goodsId).update({
                                    data: {
                                        saleStatus: 'sold'
                                    }
                                });
                            }
                        }

                        await db.collection("orders").doc(this.data.orderId).update({
                            data: updateData
                        });

                        wx.hideLoading();
                        wx.showToast({
                            title: '操作成功',
                            icon: 'success'
                        });

                        // 刷新订单详情
                        this.getOrderDetail();
                    } catch (error) {
                        console.error('更新订单状态失败:', error);
                        wx.hideLoading();
                        wx.showToast({
                            title: '操作失败，请重试',
                            icon: 'none'
                        });
                    }
                }
            }
        });
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
        this.setData({
            orderId: options.id,
            role: options.role || 'seller'
        });
        this.getOrderDetail();
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {
        this.getOrderDetail();
        wx.stopPullDownRefresh();
    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})