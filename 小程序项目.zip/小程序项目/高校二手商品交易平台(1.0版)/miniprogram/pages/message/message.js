const db = wx.cloud.database()
Page({

    /**
     * 页面的初始数据
     */
    data: {
        messageList: [],
        isLoading: true,
        activeTab: 'all', // all, unread, system, chat
        tabs: [
            { key: 'all', name: '全部消息' },
            { key: 'unread', name: '未读消息' },
            { key: 'system', name: '系统通知' },
            { key: 'chat', name: '聊天消息' }
        ]
    },

    // 切换消息标签
    switchTab(e) {
        const tab = e.currentTarget.dataset.tab;
        this.setData({
            activeTab: tab,
            isLoading: true
        });
        this.getMessages(tab);
    },

    // 获取消息列表
    getMessages(type = 'all') {
        const userId = wx.getStorageSync('id');
        if (!userId) {
            this.setData({
                isLoading: false
            });
            return;
        }

        let query = { receiverId: userId };
        
        // 根据类型筛选
        if (type === 'unread') {
            query.isRead = false;
        } else if (type === 'system') {
            query.type = 'system';
        } else if (type === 'chat') {
            query.type = 'chat';
        }

        db.collection("messages")
            .where(query)
            .orderBy('createTime', 'desc')
            .get()
            .then(res => {
                this.setData({
                    messageList: res.data,
                    isLoading: false
                });
            })
            .catch(err => {
                console.error("获取消息失败", err);
                this.setData({
                    isLoading: false
                });
                wx.showToast({
                    title: '获取消息失败',
                    icon: 'none'
                });
            });
    },

    // 查看消息详情
    viewMessage(e) {
        const message = e.currentTarget.dataset.message;
        const messageId = message._id;
        
        // 标记为已读
        if (!message.isRead) {
            db.collection("messages").doc(messageId).update({
                data: {
                    isRead: true
                }
            });
            
            // 更新本地数据
            const messageList = this.data.messageList.map(item => {
                if (item._id === messageId) {
                    item.isRead = true;
                }
                return item;
            });
            
            this.setData({ messageList });
            
            // 通知center页面更新未读数量
            getApp().globalData.needRefresh = true;
        }
        
        // 根据消息类型跳转
        if (message.type === 'chat') {
            // 跳转到聊天页面
            wx.navigateTo({
                url: `/pages/contact/contact?targetId=${message.senderId}&orderId=${message.relatedId || ''}`
            });
        } else {
            // 系统消息，显示详情
            wx.showModal({
                title: message.title,
                content: message.content,
                showCancel: false
            });
        }
    },

    // 删除消息
    deleteMessage(e) {
        const messageId = e.currentTarget.dataset.id;
        const that = this;
        
        wx.showModal({
            title: '确认删除',
            content: '确定要删除这条消息吗？',
            success: function(res) {
                if (res.confirm) {
                    db.collection("messages").doc(messageId).remove()
                        .then(res => {
                            wx.showToast({
                                title: '删除成功',
                            });
                            that.getMessages(that.data.activeTab);
                        })
                        .catch(err => {
                            console.error("删除消息失败", err);
                            wx.showToast({
                                title: '删除失败',
                                icon: 'none'
                            });
                        });
                }
            }
        });
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
        this.getMessages();
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {
        this.getMessages(this.data.activeTab);
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {
        this.getMessages(this.data.activeTab);
        wx.stopPullDownRefresh();
    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})