const db = wx.cloud.database()
let webSocketTask = null

Page({

    /**
     * 页面的初始数据
     */
    data: {
        targetId: '', // 聊天对象ID
        targetName: '', // 聊天对象名称
        orderId: '', // 相关订单ID
        messageList: [], // 消息列表
        inputMessage: '', // 输入的消息
        userInfo: null, // 用户信息
        isConnected: false, // WebSocket连接状态
        isSending: false // 是否正在发送消息
    },

    // 初始化聊天
    initChat() {
        const that = this;
        const userId = wx.getStorageSync('id');
        const userInfo = {
            id: userId,
            name: wx.getStorageSync('uname'),
            avatar: wx.getStorageSync('avator')
        };
        
        this.setData({
            userInfo: userInfo
        });
        
        // 加载历史消息
        this.loadHistoryMessages();
        
        // 连接WebSocket
        this.connectWebSocket();
    },

    // 连接WebSocket
    connectWebSocket() {
        const that = this;
        const userId = wx.getStorageSync('id');
        
        // 这里使用云函数作为WebSocket中转，实际项目中需要根据你的后端实现调整
        webSocketTask = wx.connectSocket({
            url: `wss://your-websocket-server.com/ws?userId=${userId}&targetId=${this.data.targetId}`,
            success: function() {
                console.log('WebSocket连接成功');
                that.setData({
                    isConnected: true
                });
            }
        });
        
        webSocketTask.onOpen(function(res) {
            console.log('WebSocket连接已打开');
            that.setData({
                isConnected: true
            });
        });
        
        webSocketTask.onMessage(function(res) {
            const message = JSON.parse(res.data);
            that.receiveMessage(message);
        });
        
        webSocketTask.onClose(function(res) {
            console.log('WebSocket连接已关闭');
            that.setData({
                isConnected: false
            });
        });
        
        webSocketTask.onError(function(res) {
            console.error('WebSocket连接错误', res);
            that.setData({
                isConnected: false
            });
        });
    },

    // 加载历史消息
    loadHistoryMessages() {
        const that = this;
        const userId = wx.getStorageSync('id');
        
        db.collection("chat_messages")
            .where({
                $or: [
                    {
                        senderId: userId,
                        receiverId: this.data.targetId
                    },
                    {
                        senderId: this.data.targetId,
                        receiverId: userId
                    }
                ]
            })
            .orderBy('createTime', 'asc')
            .get()
            .then(res => {
                that.setData({
                    messageList: res.data
                });
                that.scrollToBottom();
            })
            .catch(err => {
                console.error("加载聊天记录失败", err);
            });
    },

    // 接收消息
    receiveMessage(message) {
        const messageList = this.data.messageList;
        messageList.push(message);
        
        this.setData({
            messageList: messageList
        });
        
        this.scrollToBottom();
        
        // 如果是当前聊天对象的消息，标记为已读
        if (message.senderId === this.data.targetId) {
            this.markAsRead(message._id);
        }
    },

    // 发送消息
    sendMessage() {
        const that = this;
        const message = this.data.inputMessage.trim();
        
        if (!message) {
            return;
        }
        
        if (!this.data.isConnected) {
            wx.showToast({
                title: '连接已断开，请重新进入聊天',
                icon: 'none'
            });
            return;
        }
        
        this.setData({
            isSending: true
        });
        
        const newMessage = {
            senderId: this.data.userInfo.id,
            senderName: this.data.userInfo.name,
            senderAvatar: this.data.userInfo.avatar,
            receiverId: this.data.targetId,
            receiverName: this.data.targetName,
            content: message,
            type: 'text',
            createTime: new Date().toISOString(),
            isRead: false,
            relatedOrder: this.data.orderId || ''
        };
        
        // 通过WebSocket发送消息
        webSocketTask.send({
            data: JSON.stringify(newMessage),
            success: function() {
                // 发送成功后更新本地消息列表
                const messageList = that.data.messageList;
                messageList.push(newMessage);
                
                that.setData({
                    messageList: messageList,
                    inputMessage: '',
                    isSending: false
                });
                
                that.scrollToBottom();
                
                // 同时保存到数据库
                db.collection("chat_messages").add({
                    data: newMessage
                });
                
                // 发送消息通知
                that.sendMessageNotification(newMessage);
            },
            fail: function(err) {
                console.error('发送消息失败', err);
                that.setData({
                    isSending: false
                });
                wx.showToast({
                    title: '发送失败',
                    icon: 'none'
                });
            }
        });
    },

    // 发送消息通知
    sendMessageNotification(message) {
        db.collection("messages").add({
            data: {
                type: 'chat',
                title: '新消息',
                content: message.content,
                senderId: message.senderId,
                senderName: message.senderName,
                receiverId: message.receiverId,
                relatedId: message.relatedOrder,
                isRead: false,
                createTime: new Date().toISOString()
            }
        });
    },

    // 标记消息为已读
    markAsRead(messageId) {
        db.collection("chat_messages").doc(messageId).update({
            data: {
                isRead: true
            }
        });
    },

    // 滚动到底部
    scrollToBottom() {
        setTimeout(() => {
            wx.createSelectorQuery().select('.message-content').boundingClientRect(function(rect) {
                wx.createSelectorQuery().select('.message-list').scrollOffset(function(res) {
                    wx.pageScrollTo({
                        scrollTop: res.scrollHeight
                    });
                }).exec();
            }).exec();
        }, 100);
    },

    // 输入消息
    onInput(e) {
        this.setData({
            inputMessage: e.detail.value
        });
    },

    // 查看订单详情
    viewOrderDetail() {
        if (this.data.orderId) {
            wx.navigateTo({
                url: `/pages/orderDetail/orderDetail?id=${this.data.orderId}`
            });
        }
    },

    // 联系对方
    contactOther() {
        wx.makePhoneCall({
            phoneNumber: this.data.targetPhone || '10086' // 这里需要从数据库获取对方电话
        });
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
        const { targetId, orderId } = options;
        this.setData({
            targetId: targetId,
            orderId: orderId || ''
        });
        
        // 根据targetId获取对方信息
        this.getTargetInfo(targetId);
    },

    // 获取对方信息
    getTargetInfo(targetId) {
        // 这里应该从数据库获取对方信息
        // 简化处理，假设从用户集合获取
        db.collection("users").doc(targetId).get()
            .then(res => {
                this.setData({
                    targetName: res.data.name,
                    targetPhone: res.data.phone
                });
                
                wx.setNavigationBarTitle({
                    title: `与${res.data.name}的对话`
                });
                
                // 初始化聊天
                this.initChat();
            })
            .catch(err => {
                console.error("获取对方信息失败", err);
                // 如果获取失败，使用默认名称
                this.setData({
                    targetName: '用户'
                });
                
                wx.setNavigationBarTitle({
                    title: '对话'
                });
                
                // 初始化聊天
                this.initChat();
            });
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {
        // 关闭WebSocket连接
        if (webSocketTask) {
            webSocketTask.close();
        }
    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})