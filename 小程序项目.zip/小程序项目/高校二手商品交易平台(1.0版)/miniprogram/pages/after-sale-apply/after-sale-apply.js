const db = wx.cloud.database()
Page({
    data: {
        orderId: '',
        orderDetail: null,
        afterSaleTypes: ['仅退款', '退货退款', '换货', '维修'],
        formData: {
            type: '',
            reason: '',
            description: '',
            images: []
        },
        submitting: false
    },
    onLoad(options) {
        const { orderId } = options
        this.setData({ orderId })
        this.loadOrderDetail(orderId)
    },
    loadOrderDetail(orderId) {
        db.collection('orders').doc(orderId).get().then(res => {
            // 获取商品信息
            db.collection('goods').doc(res.data.goodsId).get().then(goodsRes => {
                this.setData({
                    orderDetail: {
                        ...res.data,
                        goodsData: goodsRes.data
                    }
                })
            })
        }).catch(err => {
            console.error('加载订单详情失败:', err)
            wx.showToast({
                title: '加载失败',
                icon: 'none'
            })
        })
    },
    // 选择售后类型
    chooseType(e) {
        const type = this.data.afterSaleTypes[e.detail.value]
        this.setData({
            'formData.type': type
        })
    },
    // 输入原因
    inputReason(e) {
        this.setData({
            'formData.reason': e.detail.value
        })
    },
    // 输入描述
    inputDescription(e) {
        this.setData({
            'formData.description': e.detail.value
        })
    },
    // 上传图片
    uploadImage() {
        wx.chooseImage({
            count: 3,
            sizeType: ['compressed'],
            success: async (res) => {
                const tempFilePaths = res.tempFilePaths
                const images = this.data.formData.images
                
                for (let path of tempFilePaths) {
                    wx.showLoading({ title: '上传中' })
                    try {
                        const uploadRes = await wx.cloud.uploadFile({
                            cloudPath: `after_sale/${Date.now()}-${Math.random().toString(36).substr(2, 8)}`,
                            filePath: path
                        })
                        images.push(uploadRes.fileID)
                        this.setData({
                            'formData.images': images
                        })
                    } catch (error) {
                        console.error('上传图片失败:', error)
                        wx.showToast({
                            title: '上传失败',
                            icon: 'none'
                        })
                    }
                    wx.hideLoading()
                }
            }
        })
    },
    // 删除图片
    removeImage(e) {
        const index = e.currentTarget.dataset.index
        const images = this.data.formData.images
        images.splice(index, 1)
        this.setData({
            'formData.images': images
        })
    },
    // 提交售后申请
    submitApply() {
        const { orderId, formData, orderDetail } = this.data
        const userId = wx.getStorageSync('id')
        const userName = wx.getStorageSync('uname')
        
        // 表单验证
        if (!formData.type) {
            wx.showToast({
                title: '请选择售后类型',
                icon: 'none'
            })
            return
        }
        
        if (!formData.reason) {
            wx.showToast({
                title: '请填写售后原因',
                icon: 'none'
            })
            return
        }
        
        this.setData({ submitting: true })
        
        db.collection('after_sales').add({
            data: {
                orderId: orderId,
                userId: userId,
                userName: userName,
                goodsId: orderDetail.goodsId,
                goodsTitle: orderDetail.goodsData.title,
                type: formData.type,
                reason: formData.reason,
                description: formData.description,
                images: formData.images,
                status: 'pending',
                createTime: db.serverDate(),
                updateTime: db.serverDate()
            }
        }).then(res => {
            this.setData({ submitting: false })
            wx.showToast({
                title: '提交成功',
                icon: 'success'
            })
            
            // 返回上一页
            setTimeout(() => {
                wx.navigateBack()
            }, 1500)
        }).catch(err => {
            console.error('提交售后申请失败:', err)
            this.setData({ submitting: false })
            wx.showToast({
                title: '提交失败',
                icon: 'none'
            })
        })
    }
})