// pages/category/category.js
const app = getApp();
const db = wx.cloud.database();

Page({
  data: {
    // 功能导航
    functionNavs: [
      { id: 'buy', name: '买车', icon: '../../images/buy-icon.png' },
      { id: 'sell', name: '卖车', icon: '../../images/sell-icon.png' },
      { id: 'rent', name: '租车', icon: '../../images/rent-icon.png' },
      { id: 'service', name: '售后', icon: '../../images/service-icon.png' }
    ],
    activeNav: 'buy',
    
    // 分类映射关系
    categoryMapping: {
      'buy': ['卖车'],      // 买车区显示"卖车"类商品
      'sell': ['收车'],     // 卖车区显示"收车"类商品
      'rent': ['租车', '出租'], // 租车区显示"租车"和"出租"类商品
      'service': ['质检', '维修'] // 售后区显示"质检"和"维修"类商品
    },
    
    // 地区选择
    selectedLocation: '广州大学城',
    showLocationPicker: false,
    locationOptions: [
      { value: 'gzu', label: '广州大学城' },
      { value: 'thu', label: '清华大学' },
      { value: 'pku', label: '北京大学' },
      { value: 'fdu', label: '复旦大学' },
      { value: 'sjtu', label: '上海交通大学' }
    ],
    
    // 排序和筛选
    sortType: 'default',
    showFilterPanel: false,
    activeFilterCount: 0,
    activeFilters: [],
    
    // 筛选条件
    filters: {
      priceRange: [null, null],
      brands: [],
      ranges: [],
      ages: [],
      hasInsurance: null,
      conditions: []
    },
    
    // 筛选选项
    priceRange: ['', ''],
    selectedBrands: [],
    selectedRanges: [],
    selectedAges: [],
    selectedInsurance: null,
    selectedConditions: [],
    
    brandOptions: [
      { value: 'yadea', label: '雅迪' },
      { value: 'aima', label: '爱玛' },
      { value: 'xinyri', label: '新日' },
      { value: 'tailg', label: '台铃' },
      { value: 'luyuan', label: '绿源' },
      { value: 'ninebot', label: '九号' },
      { value: 'xiaoni', label: '小牛' },
      { value: 'xiaomi', label: '小米' },
      { value: 'other', label: '其他' }
    ],
    rangeOptions: [
      { value: '0-30', label: '30km以下' },
      { value: '30-50', label: '30-50km' },
      { value: '50-70', label: '50-70km' },
      { value: '70-100', label: '70-100km' },
      { value: '100+', label: '100km以上' }
    ],
    ageOptions: [
      { value: '0-1', label: '1年以内' },
      { value: '1-2', label: '1-2年' },
      { value: '2-3', label: '2-3年' },
      { value: '3+', label: '3年以上' }
    ],
    conditionOptions: [
      { value: 'new', label: '全新' },
      { value: 'excellent', label: '优秀' },
      { value: 'good', label: '良好' },
      { value: 'fair', label: '一般' }
    ],
    
    // 商品数据
    allGoods: [],
    filteredGoods: [],
    page: 1,
    pageSize: 10,
    hasMore: true,
    isLoading: false,
    
    // 从首页跳转过来的品牌选择
    fromBrandClick: false
  },

  onLoad: function(options) {
    // 检查是否从首页品牌点击跳转过来
    const fromBrandClick = wx.getStorageSync('fromBrandClick') || false;
    const selectedBrand = wx.getStorageSync('selectedBrand') || '';
    
    if (fromBrandClick && selectedBrand) {
      this.setData({
        fromBrandClick: true,
        selectedBrands: [selectedBrand]
      });
    }
    
    this.loadGoodsFromCloud();
  },
  
  onShow: function() {
    this.setData({
      islogin: wx.getStorageSync('islogin')
    });
    
    // 检查是否有品牌筛选需求
    const fromBrandClick = wx.getStorageSync('fromBrandClick') || false;
    const selectedBrand = wx.getStorageSync('selectedBrand') || '';
    
    if (fromBrandClick && selectedBrand) {
      this.setData({
        showFilterPanel: true,
        selectedBrands: [selectedBrand],
        fromBrandClick: false
      });
      
      // 清除存储的状态
      wx.removeStorageSync('fromBrandClick');
      wx.removeStorageSync('selectedBrand');
      
      // 自动应用筛选条件
      setTimeout(() => {
        this.applyFilters();
      }, 300);
    }
  },

  // 从云数据库加载商品
  loadGoodsFromCloud: function() {
    wx.showLoading({
      title: '加载中',
    });
    
    const categories = this.data.categoryMapping[this.data.activeNav];
    
    db.collection('goods')
      .where({
        category: db.command.in(categories),
        status: 'on_sale'
      })
      .orderBy('postTime', 'desc')
      .get()
      .then(res => {
        wx.hideLoading();
        this.setData({
          allGoods: res.data,
          filteredGoods: res.data
        });
        this.applyFilters(); // 应用当前筛选条件
      })
      .catch(err => {
        wx.hideLoading();
        console.error('获取商品失败:', err);
        wx.showToast({
          title: '加载失败',
          icon: 'none'
        });
      });
  },

  // 阻止触摸事件冒泡
  preventTouchMove: function() {
    // 空函数，仅用于阻止事件冒泡
    return;
  },

  // 切换功能导航
  switchNav: function(e) {
    const navId = e.currentTarget.dataset.id;
    
    // 如果点击的是当前导航，则不操作
    if (this.data.activeNav === navId) return;
    
    this.setData({ activeNav: navId });
    
    // 特殊处理卖车和售后 - 直接跳转
    if (navId === 'sell') {
      setTimeout(() => {
        wx.navigateTo({
          url: '/pages/release/release'
        });
      }, 100);
      return;
    } else if (navId === 'service') {
      setTimeout(() => {
        wx.navigateTo({
          url: '/pages/service/service'
        });
      }, 100);
      return;
    }
    
    // 其他导航项正常加载商品
    this.loadGoodsFromCloud();
  },

  // 显示地区选择器
  showLocationPicker: function() {
    this.setData({ showLocationPicker: true });
  },

  // 隐藏地区选择器
  hideLocationPicker: function() {
    this.setData({ showLocationPicker: false });
  },

  // 选择地区
  selectLocation: function(e) {
    const { value, label } = e.currentTarget.dataset;
    this.setData({
      selectedLocation: label,
      showLocationPicker: false
    });
    
    // 根据地区筛选商品
    this.applyFilters();
  },

  // 切换排序方式
  changeSort: function(e) {
    const sortType = e.currentTarget.dataset.type;
    this.setData({ sortType });
    this.applyFilters();
  },

  // 显示筛选面板
  toggleFilterPanel: function() {
    this.setData({ showFilterPanel: !this.data.showFilterPanel });
  },

  // 隐藏筛选面板
  hideFilterPanel: function() {
    this.setData({ showFilterPanel: false });
  },

  // 最低价格输入
  onMinPriceInput: function(e) {
    const value = e.detail.value;
    this.setData({
      'priceRange[0]': value
    });
  },

  // 最高价格输入
  onMaxPriceInput: function(e) {
    const value = e.detail.value;
    this.setData({
      'priceRange[1]': value
    });
  },

  // 切换品牌选择
  toggleBrand: function(e) {
    const value = e.currentTarget.dataset.value;
    let selectedBrands = [...this.data.selectedBrands];
    
    if (selectedBrands.includes(value)) {
      const index = selectedBrands.indexOf(value);
      selectedBrands.splice(index, 1);
    } else {
      selectedBrands.push(value);
    }
    
    this.setData({ selectedBrands });
  },

  // 切换续航选择
  toggleRange: function(e) {
    const value = e.currentTarget.dataset.value;
    let selectedRanges = [...this.data.selectedRanges];
    
    if (selectedRanges.includes(value)) {
      const index = selectedRanges.indexOf(value);
      selectedRanges.splice(index, 1);
    } else {
      selectedRanges.push(value);
    }
    
    this.setData({ selectedRanges });
  },

  // 切换车龄选择
  toggleAge: function(e) {
    const value = e.currentTarget.dataset.value;
    let selectedAges = [...this.data.selectedAges];
    
    if (selectedAges.includes(value)) {
      const index = selectedAges.indexOf(value);
      selectedAges.splice(index, 1);
    } else {
      selectedAges.push(value);
    }
    
    this.setData({ selectedAges });
  },

  // 切换保险选择
  toggleInsurance: function(e) {
    const value = e.currentTarget.dataset.value;
    this.setData({
      selectedInsurance: this.data.selectedInsurance === value ? null : value
    });
  },

  // 切换车况选择
  toggleCondition: function(e) {
    const value = e.currentTarget.dataset.value;
    let selectedConditions = [...this.data.selectedConditions];
    
    if (selectedConditions.includes(value)) {
      const index = selectedConditions.indexOf(value);
      selectedConditions.splice(index, 1);
    } else {
      selectedConditions.push(value);
    }
    
    this.setData({ selectedConditions });
  },

  // 应用筛选条件
  applyFilters: function() {
    // 更新筛选条件
    const minPrice = this.data.priceRange[0] ? parseInt(this.data.priceRange[0]) : null;
    const maxPrice = this.data.priceRange[1] ? parseInt(this.data.priceRange[1]) : null;
    
    const filters = {
      priceRange: [minPrice, maxPrice],
      brands: this.data.selectedBrands,
      ranges: this.data.selectedRanges,
      ages: this.data.selectedAges,
      hasInsurance: this.data.selectedInsurance,
      conditions: this.data.selectedConditions
    };
    
    this.setData({ filters });
    
    // 生成活跃筛选条件显示
    const activeFilters = [];
    let activeFilterCount = 0;
    
    // 价格筛选
    if (minPrice !== null || maxPrice !== null) {
      let priceLabel = '价格';
      if (minPrice !== null && maxPrice !== null) {
        priceLabel += `: ${minPrice}-${maxPrice}元`;
      } else if (minPrice !== null) {
        priceLabel += `: ${minPrice}元以上`;
      } else if (maxPrice !== null) {
        priceLabel += `: ${maxPrice}元以下`;
      }
      
      activeFilters.push({ key: 'price', label: '价格', value: `${minPrice || ''}-${maxPrice || ''}` });
      activeFilterCount++;
    }
    
    // 品牌筛选
    if (filters.brands.length > 0) {
      const brandLabels = filters.brands.map(brand => {
        const option = this.data.brandOptions.find(opt => opt.value === brand);
        return option ? option.label : brand;
      });
      
      activeFilters.push({ 
        key: 'brands', 
        label: '品牌', 
        value: brandLabels.join(',') 
      });
      activeFilterCount++;
    }
    
    // 续航筛选
    if (filters.ranges.length > 0) {
      const rangeLabels = filters.ranges.map(range => {
        const option = this.data.rangeOptions.find(opt => opt.value === range);
        return option ? option.label : range;
      });
      
      activeFilters.push({ 
        key: 'ranges', 
        label: '续航', 
        value: rangeLabels.join(',') 
      });
      activeFilterCount++;
    }
    
    // 车龄筛选
    if (filters.ages.length > 0) {
      const ageLabels = filters.ages.map(age => {
        const option = this.data.ageOptions.find(opt => opt.value === age);
        return option ? option.label : age;
      });
      
      activeFilters.push({ 
        key: 'ages', 
        label: '车龄', 
        value: ageLabels.join(',') 
      });
      activeFilterCount++;
    }
    
    // 保险筛选
    if (filters.hasInsurance !== null) {
      activeFilters.push({ 
        key: 'hasInsurance', 
        label: '保险', 
        value: filters.hasInsurance === 'true' ? '有' : '无' 
      });
      activeFilterCount++;
    }
    
    // 车况筛选
    if (filters.conditions.length > 0) {
      const conditionLabels = filters.conditions.map(condition => {
        const option = this.data.conditionOptions.find(opt => opt.value === condition);
        return option ? option.label : condition;
      });
      
      activeFilters.push({ 
        key: 'conditions', 
        label: '车况', 
        value: conditionLabels.join(',') 
      });
      activeFilterCount++;
    }
    
    // 筛选商品
    let filteredGoods = [...this.data.allGoods];
    
    // 价格筛选
    if (minPrice !== null) {
      filteredGoods = filteredGoods.filter(item => item.price >= minPrice);
    }
    
    if (maxPrice !== null) {
      filteredGoods = filteredGoods.filter(item => item.price <= maxPrice);
    }
    
    // 品牌筛选
    if (filters.brands.length > 0) {
      filteredGoods = filteredGoods.filter(item => filters.brands.includes(item.brand));
    }
    
    // 续航筛选
    if (filters.ranges.length > 0) {
      filteredGoods = filteredGoods.filter(item => {
        const range = item.range || 0;
        return filters.ranges.some(r => {
          if (r === '100+') return range >= 100;
          const [min, max] = r.split('-').map(Number);
          return range >= min && range <= max;
        });
      });
    }
    
    // 车龄筛选
    if (filters.ages.length > 0) {
      filteredGoods = filteredGoods.filter(item => {
        const age = item.age || 0;
        return filters.ages.some(a => {
          if (a === '3+') return age >= 3;
          const [min, max] = a.split('-').map(Number);
          return age >= min && age <= max;
        });
      });
    }
    
    // 保险筛选
    if (filters.hasInsurance !== null) {
      filteredGoods = filteredGoods.filter(item => {
        const hasInsurance = item.hasInsurance === true || item.hasInsurance === 'true';
        return hasInsurance === (filters.hasInsurance === 'true');
      });
    }
    
    // 车况筛选
    if (filters.conditions.length > 0) {
      filteredGoods = filteredGoods.filter(item => filters.conditions.includes(item.condition));
    }
    
    // 排序
    if (this.data.sortType === 'priceAsc') {
      filteredGoods.sort((a, b) => a.price - b.price);
    } else if (this.data.sortType === 'priceDesc') {
      filteredGoods.sort((a, b) => b.price - a.price);
    } else if (this.data.sortType === 'timeDesc') {
      filteredGoods.sort((a, b) => new Date(b.postTime) - new Date(a.postTime));
    }
    
    this.setData({
      filteredGoods,
      activeFilters,
      activeFilterCount,
      showFilterPanel: false
    });
  },

  // 重置筛选条件
  resetFilters: function() {
    this.setData({
      priceRange: ['', ''],
      selectedBrands: [],
      selectedRanges: [],
      selectedAges: [],
      selectedInsurance: null,
      selectedConditions: []
    });
  },

  // 移除单个筛选条件
removeFilter: function(e) {
  const { key } = e.currentTarget.dataset;
  const index = e.currentTarget.dataset.index; // 添加index参数
  
  if (key === 'price') {
    this.setData({
      priceRange: ['', '']
    });
  } else if (key === 'brands') {
    const selectedBrands = [...this.data.selectedBrands];
    selectedBrands.splice(index, 1);
    this.setData({ selectedBrands });
  } else if (key === 'ranges') {
    const selectedRanges = [...this.data.selectedRanges];
    selectedRanges.splice(index, 1);
    this.setData({ selectedRanges });
  } else if (key === 'ages') {
    const selectedAges = [...this.data.selectedAges];
    selectedAges.splice(index, 1);
    this.setData({ selectedAges });
  } else if (key === 'hasInsurance') {
    this.setData({ selectedInsurance: null });
  } else if (key === 'conditions') {
    const selectedConditions = [...this.data.selectedConditions];
    selectedConditions.splice(index, 1);
    this.setData({ selectedConditions });
  }
  
  // 重新应用筛选
  setTimeout(() => {
    this.applyFilters();
  }, 100);
},
  // 监听页面隐藏
onHide: function() {
  console.log('页面隐藏，清空筛选条件');
  this.clearAllFilters();
},

// 清空所有筛选条件
clearAllFilters: function() {
  this.setData({
    priceRange: ['', ''],
    selectedBrands: [],
    selectedRanges: [],
    selectedAges: [],
    selectedInsurance: null,
    selectedConditions: [],
    activeFilters: [],
    activeFilterCount: 0,
    filters: {
      priceRange: [null, null],
      brands: [],
      ranges: [],
      ages: [],
      hasInsurance: null,
      conditions: []
    }
  });
  
  // 重新加载商品（显示所有商品）
  this.loadGoodsFromCloud();
},

  // 加载更多商品
  loadMore: function() {
    if (this.data.isLoading || !this.data.hasMore) return;
    
    this.setData({ isLoading: true });
    
    // 模拟加载更多数据
    setTimeout(() => {
      const newGoods = this.data.filteredGoods.slice(0, this.data.pageSize);
      const filteredGoods = [...this.data.filteredGoods, ...newGoods];
      
      this.setData({
        filteredGoods,
        page: this.data.page + 1,
        isLoading: false,
        hasMore: filteredGoods.length < 50 // 假设最多50条数据
      });
    }, 1000);
  },

  // 跳转到商品详情页
  navigateToDetail: function(e) {
    const id = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: `/pages/detail/detail?id=${id}`
    });
  }
});