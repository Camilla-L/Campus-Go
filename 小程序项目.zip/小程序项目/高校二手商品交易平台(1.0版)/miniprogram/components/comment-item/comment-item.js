Component({
  properties: {
    comment: {
      type: Object,
      value: {}
    }
  },

  methods: {
    // 回复评论
    onReply(e) {
      const comment = e.currentTarget.dataset.comment;
      this.triggerEvent('reply', { comment });
    },

    // 点赞评论
    onLike(e) {
      const comment = e.currentTarget.dataset.comment;
      this.triggerEvent('like', { 
        commentId: comment.id,
        type: 'comment'
      });
    },

    // 回复子评论
    onReplyReply(e) {
      const comment = e.currentTarget.dataset.comment;
      const reply = e.currentTarget.dataset.reply;
      this.triggerEvent('reply', { 
        comment,
        reply 
      });
    },

    // 点赞子评论
    onLikeReply(e) {
      const comment = e.currentTarget.dataset.comment;
      const reply = e.currentTarget.dataset.reply;
      this.triggerEvent('like', { 
        commentId: comment.id,
        replyId: reply.id,
        type: 'reply'
      });
    }
  }
});